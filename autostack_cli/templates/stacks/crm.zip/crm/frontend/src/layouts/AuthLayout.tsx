import { Outlet } from 'react-router-dom';

export default function AuthLayout() {
  return (
    <div className="flex min-h-screen flex-col">
      <div className="flex min-h-screen w-full flex-col bg-background sm:grid sm:grid-cols-[1fr_400px]">
        {/* Left side - Hero Image */}
        <div className="hidden bg-muted sm:block">
          <div 
            className="h-full w-full bg-cover bg-center bg-no-repeat"
            style={{
              backgroundImage: 'url("https://images.unsplash.com/photo-1568992687947-868a62a9f521?w=800&h=1200&q=80")',
            }}
          />
        </div>
        
        {/* Right side - Auth Form */}
        <div className="flex items-center justify-center p-6">
          <div className="w-full space-y-6">
            <div className="space-y-2 text-center">
              <h1 className="text-3xl font-bold">HRMS</h1>
              <p className="text-muted-foreground">Human Resource Management System</p>
            </div>
            
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
} 
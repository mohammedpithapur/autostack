import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { useAuth } from '../hooks/useAuth';

interface LeaveRequest {
  id: number;
  employee_name: string;
  leave_type: string;
  start_date: string;
  end_date: string;
  reason: string;
  status: string;
}

export default function Leave() {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Leave request collections
  const [pendingLeaves, setPendingLeaves] = useState<LeaveRequest[]>([]);
  const [approvedLeaves, setApprovedLeaves] = useState<LeaveRequest[]>([]);
  const [rejectedLeaves, setRejectedLeaves] = useState<LeaveRequest[]>([]);
  
  // Summary counts
  const [pendingCount, setPendingCount] = useState(0);
  const [approvedCount, setApprovedCount] = useState(0);
  const [rejectedCount, setRejectedCount] = useState(0);
  const [onLeaveToday, setOnLeaveToday] = useState(0);
  
  // Modal state
  const [showNewLeaveModal, setShowNewLeaveModal] = useState(false);
  const [showEditLeaveModal, setShowEditLeaveModal] = useState(false);
  const [selectedLeave, setSelectedLeave] = useState<LeaveRequest | null>(null);
  
  // New leave form state
  const [newLeave, setNewLeave] = useState({
    leave_type: 'vacation',
    start_date: '',
    end_date: '',
    reason: ''
  });

  // Load leave data
  const loadLeaveData = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get('/api/leave/');
      
      if (response.data) {
        setPendingLeaves(response.data.leaves_by_status?.pending || []);
        setApprovedLeaves(response.data.leaves_by_status?.approved || []);
        setRejectedLeaves(response.data.leaves_by_status?.rejected || []);
        
        setPendingCount(response.data.pending_count || 0);
        setApprovedCount(response.data.approved_count || 0);
        setRejectedCount(response.data.rejected_count || 0);
        
        // Calculate on leave today
        const today = new Date().toISOString().split('T')[0];
        const onLeave = response.data.leave_requests?.filter((leave: LeaveRequest) => {
          return (
            leave.status === 'approved' &&
            today >= leave.start_date &&
            today <= leave.end_date
          );
        }).length || 0;
        
        setOnLeaveToday(onLeave);
      }
    } catch (error) {
      console.error('Failed to load leave data:', error);
      toast.error('Failed to load leave data');
    } finally {
      setIsLoading(false);
    }
  };

  // Submit new leave request
  const submitLeaveRequest = async () => {
    try {
      setIsSubmitting(true);
      await axios.post('/api/leave/', newLeave);
      toast.success('Leave request submitted successfully');
      setShowNewLeaveModal(false);
      setNewLeave({
        leave_type: 'vacation',
        start_date: '',
        end_date: '',
        reason: ''
      });
      loadLeaveData(); // Reload data
    } catch (error: any) {
      console.error('Failed to submit leave request:', error);
      toast.error(error.response?.data?.message || 'Failed to submit leave request');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update leave request
  const updateLeaveRequest = async (leaveId: number, data: any) => {
    try {
      setIsSubmitting(true);
      const response = await axios.put(`/api/leave/${leaveId}`, data);
      
      // Verify we got a response with updated leave data
      if (!response.data || !response.data.leave) {
        throw new Error('Invalid response from server');
      }
      
      toast.success('Leave request updated successfully');
      setShowEditLeaveModal(false);
      setSelectedLeave(null);
      await loadLeaveData(); // Reload all data
      
    } catch (error: any) {
      console.error('Failed to update leave request:', error);
      toast.error(error.response?.data?.message || 'Failed to update leave request');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update leave request status (for admin users)
  const updateLeaveStatus = async (leaveId: number, status: string) => {
    try {
      const response = await axios.put(`/api/leave/${leaveId}`, { status });
      
      if (!response.data || !response.data.leave) {
        throw new Error('Invalid response from server');
      }
      
      toast.success(`Leave request ${status}`);
      await loadLeaveData(); // Reload data
      
    } catch (error: any) {
      console.error('Failed to update leave request:', error);
      toast.error(error.response?.data?.message || 'Failed to update leave status');
    }
  };

  // Delete leave request
  const deleteLeaveRequest = async (leaveId: number) => {
    try {
      await axios.delete(`/api/leave/${leaveId}`);
      toast.success('Leave request deleted successfully');
      await loadLeaveData(); // Reload data
    } catch (error: any) {
      console.error('Failed to delete leave request:', error);
      toast.error(error.response?.data?.message || 'Failed to delete leave request');
    }
  };

  // Calculate days between two dates
  const calculateDays = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  };

  // Format date range for display
  const formatDateRange = (startDate: string, endDate: string) => {
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    // If same day
    if (startDate === endDate) {
      return new Intl.DateTimeFormat('en-US', { 
        month: 'short', 
        day: 'numeric' 
      }).format(start);
    }
    
    // If same month
    if (start.getMonth() === end.getMonth()) {
      return `${new Intl.DateTimeFormat('en-US', { month: 'short' }).format(start)} ${start.getDate()}-${end.getDate()}`;
    }
    
    // Different months
    return `${new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(start)} - ${new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(end)}`;
  };

  // Handle edit leave request
  const handleEditLeave = (leave: LeaveRequest) => {
    // Convert dates to YYYY-MM-DD format for inputs
    const formattedLeave = {
      ...leave,
      start_date: new Date(leave.start_date).toISOString().split('T')[0],
      end_date: new Date(leave.end_date).toISOString().split('T')[0]
    };
    
    setSelectedLeave(formattedLeave);
    setShowEditLeaveModal(true);
  };

  // Load data on component mount
  useEffect(() => {
    loadLeaveData();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Leave Management</h2>
          <p className="text-muted-foreground">Track and manage employee leave requests.</p>
        </div>
        <button 
          onClick={() => setShowNewLeaveModal(true)}
          className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          New Request
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-muted-foreground">Pending Requests</span>
            <span className="text-3xl font-bold">{pendingCount}</span>
          </div>
        </div>
        
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-muted-foreground">Approved</span>
            <span className="text-3xl font-bold">{approvedCount}</span>
          </div>
        </div>
        
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-muted-foreground">Rejected</span>
            <span className="text-3xl font-bold">{rejectedCount}</span>
          </div>
        </div>
        
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex flex-col">
            <span className="text-sm font-medium text-muted-foreground">On Leave Today</span>
            <span className="text-3xl font-bold">{onLeaveToday}</span>
          </div>
        </div>
      </div>
      
      {/* Leave requests kanban board */}
      <div>
        <h3 className="mb-4 text-xl font-semibold">Leave Requests</h3>
        
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {/* Pending column */}
            <div className="rounded-lg border bg-card shadow-sm">
              <div className="border-b p-4">
                <h4 className="font-semibold">Pending</h4>
              </div>
              <div className="p-4 space-y-4 min-h-[200px]">
                {pendingLeaves.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">No pending requests</p>
                ) : (
                  pendingLeaves.map((request) => (
                    <div key={request.id} className="rounded-lg border p-3 bg-background shadow-sm">
                      <div className="font-medium">{request.employee_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {request.leave_type.charAt(0).toUpperCase() + request.leave_type.slice(1)} • {calculateDays(request.start_date, request.end_date)} days
                      </div>
                      <div className="mt-2 text-xs font-medium">{formatDateRange(request.start_date, request.end_date)}</div>
                      
                      {request.reason && (
                        <div className="mt-2 text-sm border-t pt-2">
                          <span className="text-muted-foreground">Reason: </span>
                          {request.reason}
                        </div>
                      )}
                      
                      <div className="flex justify-between mt-3">
                        <button 
                          onClick={() => handleEditLeave(request)}
                          className="px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200"
                        >
                          Edit
                        </button>
                        
                        {user?.role === 'admin' && (
                          <div className="flex space-x-2">
                            <button 
                              onClick={() => updateLeaveStatus(request.id, 'approved')}
                              className="px-2 py-1 text-xs bg-green-100 text-green-800 rounded-md hover:bg-green-200"
                            >
                              Approve
                            </button>
                            <button 
                              onClick={() => updateLeaveStatus(request.id, 'rejected')}
                              className="px-2 py-1 text-xs bg-red-100 text-red-800 rounded-md hover:bg-red-200"
                            >
                              Reject
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
            
            {/* Approved column */}
            <div className="rounded-lg border bg-card shadow-sm">
              <div className="border-b p-4">
                <h4 className="font-semibold">Approved</h4>
              </div>
              <div className="p-4 space-y-4 min-h-[200px]">
                {approvedLeaves.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">No approved requests</p>
                ) : (
                  approvedLeaves.map((request) => (
                    <div key={request.id} className="rounded-lg border p-3 bg-background shadow-sm">
                      <div className="font-medium">{request.employee_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {request.leave_type.charAt(0).toUpperCase() + request.leave_type.slice(1)} • {calculateDays(request.start_date, request.end_date)} days
                      </div>
                      <div className="mt-2 text-xs font-medium">{formatDateRange(request.start_date, request.end_date)}</div>
                      
                      {request.reason && (
                        <div className="mt-2 text-sm border-t pt-2">
                          <span className="text-muted-foreground">Reason: </span>
                          {request.reason}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
            
            {/* Rejected column */}
            <div className="rounded-lg border bg-card shadow-sm">
              <div className="border-b p-4">
                <h4 className="font-semibold">Rejected</h4>
              </div>
              <div className="p-4 space-y-4 min-h-[200px]">
                {rejectedLeaves.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">No rejected requests</p>
                ) : (
                  rejectedLeaves.map((request) => (
                    <div key={request.id} className="rounded-lg border p-3 bg-background shadow-sm">
                      <div className="font-medium">{request.employee_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {request.leave_type.charAt(0).toUpperCase() + request.leave_type.slice(1)} • {calculateDays(request.start_date, request.end_date)} days
                      </div>
                      <div className="mt-2 text-xs font-medium">{formatDateRange(request.start_date, request.end_date)}</div>
                      
                      {request.reason && (
                        <div className="mt-2 text-sm border-t pt-2">
                          <span className="text-muted-foreground">Reason: </span>
                          {request.reason}
                        </div>
                      )}
                      
                      <button 
                        onClick={() => deleteLeaveRequest(request.id)}
                        className="mt-3 px-2 py-1 text-xs bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 w-full text-center"
                      >
                        Remove
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
      
      {/* New Leave Request Modal */}
      {showNewLeaveModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">New Leave Request</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Leave Type</label>
                <select 
                  value={newLeave.leave_type}
                  onChange={(e) => setNewLeave({...newLeave, leave_type: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting}
                >
                  <option value="vacation">Vacation</option>
                  <option value="sick">Sick Leave</option>
                  <option value="personal">Personal Leave</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Start Date</label>
                <input 
                  type="date" 
                  value={newLeave.start_date}
                  onChange={(e) => setNewLeave({...newLeave, start_date: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">End Date</label>
                <input 
                  type="date"
                  value={newLeave.end_date}
                  onChange={(e) => setNewLeave({...newLeave, end_date: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Reason (Optional)</label>
                <textarea
                  value={newLeave.reason}
                  onChange={(e) => setNewLeave({...newLeave, reason: e.target.value})}
                  className="w-full p-2 border rounded-md resize-none h-24"
                  placeholder="Provide a reason for your leave request..."
                  disabled={isSubmitting}
                ></textarea>
              </div>
              
              <div className="flex justify-end space-x-2 mt-2">
                <button 
                  onClick={() => setShowNewLeaveModal(false)}
                  className="px-4 py-2 text-sm border rounded-md"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button 
                  onClick={submitLeaveRequest}
                  disabled={isSubmitting || !newLeave.leave_type || !newLeave.start_date || !newLeave.end_date}
                  className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md disabled:opacity-50"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Request'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Edit Leave Request Modal */}
      {showEditLeaveModal && selectedLeave && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Edit Leave Request</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Leave Type</label>
                <select 
                  value={selectedLeave.leave_type}
                  onChange={(e) => setSelectedLeave({...selectedLeave, leave_type: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting || selectedLeave.status !== 'pending'}
                >
                  <option value="vacation">Vacation</option>
                  <option value="sick">Sick Leave</option>
                  <option value="personal">Personal Leave</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Start Date</label>
                <input 
                  type="date" 
                  value={selectedLeave.start_date}
                  onChange={(e) => setSelectedLeave({...selectedLeave, start_date: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting || selectedLeave.status !== 'pending'}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">End Date</label>
                <input 
                  type="date"
                  value={selectedLeave.end_date}
                  onChange={(e) => setSelectedLeave({...selectedLeave, end_date: e.target.value})}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting || selectedLeave.status !== 'pending'}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Reason (Optional)</label>
                <textarea
                  value={selectedLeave.reason || ''}
                  onChange={(e) => setSelectedLeave({...selectedLeave, reason: e.target.value})}
                  className="w-full p-2 border rounded-md resize-none h-24"
                  placeholder="Provide a reason for your leave request..."
                  disabled={isSubmitting || selectedLeave.status !== 'pending'}
                ></textarea>
              </div>
              
              <div className="flex justify-end space-x-2 mt-2">
                <button 
                  onClick={() => setShowEditLeaveModal(false)}
                  className="px-4 py-2 text-sm border rounded-md"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                {selectedLeave.status === 'pending' && (
                  <button 
                    onClick={() => updateLeaveRequest(selectedLeave.id, {
                      leave_type: selectedLeave.leave_type,
                      start_date: selectedLeave.start_date,
                      end_date: selectedLeave.end_date,
                      reason: selectedLeave.reason
                    })}
                    disabled={isSubmitting || !selectedLeave.leave_type || !selectedLeave.start_date || !selectedLeave.end_date}
                    className="px-4 py-2 text-sm bg-primary text-primary-foreground rounded-md disabled:opacity-50"
                  >
                    {isSubmitting ? 'Saving...' : 'Save Changes'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 
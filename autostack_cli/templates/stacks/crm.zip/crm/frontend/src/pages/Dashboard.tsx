import { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Users,
  CalendarCheck,
  Clock,
  CheckCircle2,
  XCircle,
  BarChart3,
} from 'lucide-react';

// Types
interface DashboardStat {
  id: string;
  label: string;
  value: number;
  icon: JSX.Element;
  change: number;
}

interface EmployeeActivity {
  id: number;
  name: string;
  action: string;
  timestamp: string;
  status: 'approved' | 'pending' | 'rejected';
}

interface ApiResponse {
  stats: {
    total_employees: number;
    present_today: number;
    on_leave: number;
    open_positions: number;
  };
  activities: Array<{
    id: number;
    name: string;
    action: string;
    timestamp: string;
    status: string;
  }>;
}

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStat[]>([]);
  const [activities, setActivities] = useState<EmployeeActivity[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        // Try to fetch data from our API
        try {
          const response = await axios.get<ApiResponse>('/api/dashboard/');
          
          if (response.data && response.data.stats) {
            // Transform API data to our component format
            setStats([
              {
                id: 'total-employees',
                label: 'Total Employees',
                value: response.data.stats.total_employees || 0,
                change: 12, // Mock change percentage
                icon: <Users size={24} className="text-blue-500" />,
              },
              {
                id: 'present-today',
                label: 'Present Today',
                value: response.data.stats.present_today || 0,
                change: -5,
                icon: <CalendarCheck size={24} className="text-green-500" />,
              },
              {
                id: 'on-leave',
                label: 'On Leave',
                value: response.data.stats.on_leave || 0,
                change: 3,
                icon: <Clock size={24} className="text-orange-500" />,
              },
              {
                id: 'open-positions',
                label: 'Open Positions',
                value: response.data.stats.open_positions || 0,
                change: 2,
                icon: <BarChart3 size={24} className="text-purple-500" />,
              },
            ]);
            
            // Transform activities if available
            if (response.data.activities && Array.isArray(response.data.activities)) {
              setActivities(
                response.data.activities.map(activity => ({
                  id: activity.id,
                  name: activity.name,
                  action: activity.action,
                  timestamp: activity.timestamp,
                  status: activity.status as 'approved' | 'pending' | 'rejected',
                }))
              );
            }
          } else {
            throw new Error('Invalid data structure received from API');
          }
        } catch (apiError) {
          console.error('Error fetching from API, using mock data instead:', apiError);
          
          // Fallback to mock data
          setStats([
            {
              id: 'total-employees',
              label: 'Total Employees',
              value: 245,
              change: 12,
              icon: <Users size={24} className="text-blue-500" />,
            },
            {
              id: 'present-today',
              label: 'Present Today',
              value: 198,
              change: -5,
              icon: <CalendarCheck size={24} className="text-green-500" />,
            },
            {
              id: 'on-leave',
              label: 'On Leave',
              value: 24,
              change: 3,
              icon: <Clock size={24} className="text-orange-500" />,
            },
            {
              id: 'open-positions',
              label: 'Open Positions',
              value: 12,
              change: 2,
              icon: <BarChart3 size={24} className="text-purple-500" />,
            },
          ]);
          
          // Mock activities
          setActivities([
            {
              id: 1,
              name: 'John Smith',
              action: 'Requested leave from 15th to 18th May',
              timestamp: '2 hours ago',
              status: 'approved',
            },
            {
              id: 2,
              name: 'Emily Johnson',
              action: 'Clocked in late',
              timestamp: '3 hours ago',
              status: 'pending',
            },
            {
              id: 3,
              name: 'Michael Williams',
              action: 'Requested equipment purchase',
              timestamp: '5 hours ago',
              status: 'rejected',
            },
            {
              id: 4,
              name: 'Sarah Davis',
              action: 'Completed onboarding',
              timestamp: '1 day ago',
              status: 'approved',
            },
            {
              id: 5,
              name: 'James Rodriguez',
              action: 'Updated personal information',
              timestamp: '1 day ago',
              status: 'approved',
            },
          ]);
        }
      } catch (error) {
        console.error('Error loading dashboard data:', error);
        setError('Failed to load dashboard data. Please try again later.');
      } finally {
        setIsLoading(false);
      }
    };
    
    loadDashboardData();
  }, []);
  
  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-4rem)] items-center justify-center">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex h-[calc(100vh-4rem)] flex-col items-center justify-center">
        <div className="text-red-500 mb-4">⚠️ {error}</div>
        <button 
          onClick={() => window.location.reload()}
          className="px-4 py-2 bg-primary text-white rounded-md"
        >
          Retry
        </button>
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <p className="text-muted-foreground">
          Overview of your organization's key metrics and recent activities.
        </p>
      </div>
      
      {/* Stats */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.id}
            className="rounded-lg border bg-card p-6 shadow-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{stat.label}</span>
              <div className="rounded-full p-2 bg-primary/10">{stat.icon}</div>
            </div>
            <div className="mt-3">
              <span className="text-3xl font-bold">{stat.value}</span>
              <div className="mt-1 flex items-center text-sm">
                <span
                  className={`mr-1 ${
                    stat.change > 0 ? 'text-green-500' : 'text-red-500'
                  }`}
                >
                  {stat.change > 0 ? '+' : ''}{stat.change}%
                </span>
                <span className="text-muted-foreground">vs. last month</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Recent Activity */}
      <div>
        <h3 className="mb-4 text-xl font-semibold">Recent Activity</h3>
        <div className="rounded-lg border bg-card shadow-sm">
          <div className="p-6">
            {activities.length > 0 ? (
              activities.map((activity) => (
                <div
                  key={activity.id}
                  className="mb-4 flex items-center justify-between border-b pb-4 last:mb-0 last:border-0 last:pb-0"
                >
                  <div className="flex items-center">
                    <div className="mr-4 h-10 w-10 overflow-hidden rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="font-medium">{activity.name ? activity.name.charAt(0) : '?'}</span>
                    </div>
                    <div>
                      <p className="font-medium">{activity.name}</p>
                      <p className="text-sm text-muted-foreground">{activity.action}</p>
                      <span className="text-xs text-muted-foreground">{activity.timestamp}</span>
                    </div>
                  </div>
                  <div>
                    {activity.status === 'approved' && (
                      <span className="flex items-center rounded-full bg-green-100 px-3 py-1 text-xs text-green-600">
                        <CheckCircle2 size={14} className="mr-1" /> Approved
                      </span>
                    )}
                    {activity.status === 'pending' && (
                      <span className="flex items-center rounded-full bg-amber-100 px-3 py-1 text-xs text-amber-600">
                        <Clock size={14} className="mr-1" /> Pending
                      </span>
                    )}
                    {activity.status === 'rejected' && (
                      <span className="flex items-center rounded-full bg-red-100 px-3 py-1 text-xs text-red-600">
                        <XCircle size={14} className="mr-1" /> Rejected
                      </span>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                No recent activities found
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
} 
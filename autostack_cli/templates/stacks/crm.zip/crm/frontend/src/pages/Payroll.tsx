import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { useAuth } from '../hooks/useAuth';

// Define types for payroll records
interface PayrollRecord {
  id: number;
  employee_name: string;
  employee_id: number;
  pay_period_start: string;
  pay_period_end: string;
  base_salary: number;
  overtime: number;
  deductions: number;
  net_pay: number;
  status: string;
  payment_date?: string;
}

interface Employee {
  id: number;
  name: string;
}

export default function Payroll() {
  const { user } = useAuth();
  const [payrolls, setPayrolls] = useState<PayrollRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showNewPayrollModal, setShowNewPayrollModal] = useState(false);
  const [selectedPayroll, setSelectedPayroll] = useState<PayrollRecord | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // New payroll form state
  const [newPayroll, setNewPayroll] = useState({
    employee_id: '',
    pay_period_start: '',
    pay_period_end: '',
    base_salary: '',
    overtime: '0',
    deductions: '0',
    net_pay: '',
    status: 'pending'
  });
  
  // Stats
  const [totalPayroll, setTotalPayroll] = useState(0);
  const [pendingPayments, setPendingPayments] = useState(0);
  const [averageSalary, setAverageSalary] = useState(0);

  // Load payroll data from backend
  const loadPayrollData = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get('/api/payroll/');
      
      if (response.data && response.data.payroll_records) {
        setPayrolls(response.data.payroll_records);
        
        // Calculate stats
        const records = response.data.payroll_records as PayrollRecord[];
        const total = records.reduce((sum, record) => sum + record.net_pay, 0);
        const pending = records.filter(record => record.status === 'pending').length;
        const avg = records.length > 0 ? total / records.length : 0;
        
        setTotalPayroll(total);
        setPendingPayments(pending);
        setAverageSalary(avg);
      } else {
        // Use mock data as fallback
        const mockData = [
          { id: 1, employee_id: 1, employee_name: 'John Smith', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 4500, overtime: 0, deductions: 650, net_pay: 3850, status: 'paid' },
          { id: 2, employee_id: 2, employee_name: 'Sarah Davis', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 5200, overtime: 0, deductions: 780, net_pay: 4420, status: 'paid' },
          { id: 3, employee_id: 3, employee_name: 'Michael Williams', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 3800, overtime: 0, deductions: 570, net_pay: 3230, status: 'pending' },
          { id: 4, employee_id: 4, employee_name: 'Emily Johnson', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 4700, overtime: 0, deductions: 705, net_pay: 3995, status: 'paid' }
        ];
        
        setPayrolls(mockData);
        setTotalPayroll(mockData.reduce((sum, record) => sum + record.net_pay, 0));
        setPendingPayments(mockData.filter(record => record.status === 'pending').length);
        setAverageSalary(mockData.reduce((sum, record) => sum + record.base_salary, 0) / mockData.length);
      }
    } catch (error) {
      console.error('Failed to load payroll data:', error);
      toast.error('Failed to load payroll data');
      
      // Use mock data as fallback
      const mockData = [
        { id: 1, employee_id: 1, employee_name: 'John Smith', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 4500, overtime: 0, deductions: 650, net_pay: 3850, status: 'paid' },
        { id: 2, employee_id: 2, employee_name: 'Sarah Davis', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 5200, overtime: 0, deductions: 780, net_pay: 4420, status: 'paid' },
        { id: 3, employee_id: 3, employee_name: 'Michael Williams', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 3800, overtime: 0, deductions: 570, net_pay: 3230, status: 'pending' },
        { id: 4, employee_id: 4, employee_name: 'Emily Johnson', pay_period_start: '2023-05-01', pay_period_end: '2023-05-15', base_salary: 4700, overtime: 0, deductions: 705, net_pay: 3995, status: 'paid' }
      ];
      
      setPayrolls(mockData);
      setTotalPayroll(mockData.reduce((sum, record) => sum + record.net_pay, 0));
      setPendingPayments(mockData.filter(record => record.status === 'pending').length);
      setAverageSalary(mockData.reduce((sum, record) => sum + record.base_salary, 0) / mockData.length);
    } finally {
      setIsLoading(false);
    }
  };

  // Load employees
  const loadEmployees = async () => {
    try {
      const response = await axios.get('/api/employees/');
      if (response.data && response.data.employees) {
        const empList = response.data.employees.map((emp: any) => ({
          id: emp.id,
          name: emp.user ? emp.user.name : 'Unknown'
        }));
        setEmployees(empList);
      }
    } catch (error) {
      console.error('Failed to load employees:', error);
      // Use mock employees as fallback
      setEmployees([
        { id: 1, name: 'John Smith' },
        { id: 2, name: 'Sarah Davis' },
        { id: 3, name: 'Michael Williams' },
        { id: 4, name: 'Emily Johnson' }
      ]);
    }
  };

  // Handle form input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewPayroll({
      ...newPayroll,
      [name]: value
    });
    
    // Auto-calculate net pay when base salary, overtime, or deductions change
    if (['base_salary', 'overtime', 'deductions'].includes(name)) {
      const baseSalary = parseFloat(name === 'base_salary' ? value : newPayroll.base_salary) || 0;
      const overtime = parseFloat(name === 'overtime' ? value : newPayroll.overtime) || 0;
      const deductions = parseFloat(name === 'deductions' ? value : newPayroll.deductions) || 0;
      
      const netPay = baseSalary + overtime - deductions;
      if (!isNaN(netPay)) {
        setNewPayroll(prev => ({
          ...prev,
          net_pay: netPay.toString()
        }));
      }
    }
  };

  // Create new payroll
  const handleCreatePayroll = async () => {
    try {
      setIsSubmitting(true);
      
      // Calculate net pay if needed
      let netPay = parseFloat(newPayroll.net_pay);
      if (!newPayroll.net_pay) {
        const baseSalary = parseFloat(newPayroll.base_salary);
        const overtime = parseFloat(newPayroll.overtime || '0');
        const deductions = parseFloat(newPayroll.deductions || '0');
        netPay = baseSalary + overtime - deductions;
      }
      
      const payload = {
        employee_id: parseInt(newPayroll.employee_id),
        pay_period_start: newPayroll.pay_period_start,
        pay_period_end: newPayroll.pay_period_end,
        base_salary: parseFloat(newPayroll.base_salary),
        overtime: parseFloat(newPayroll.overtime || '0'),
        deductions: parseFloat(newPayroll.deductions || '0'),
        net_pay: netPay,
        status: newPayroll.status
      };
      
      await axios.post('/api/payroll/', payload);
      toast.success('Payroll record created successfully');
      setShowNewPayrollModal(false);
      
      // Reset form
      setNewPayroll({
        employee_id: '',
        pay_period_start: '',
        pay_period_end: '',
        base_salary: '',
        overtime: '0',
        deductions: '0',
        net_pay: '',
        status: 'pending'
      });
      
      // Reload data
      loadPayrollData();
      
    } catch (error) {
      console.error('Failed to create payroll record:', error);
      toast.error('Failed to create payroll record');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Update payroll status
  const handleUpdateStatus = async (payrollId: number, status: string) => {
    try {
      await axios.put(`/api/payroll/${payrollId}`, { status });
      toast.success(`Payroll status updated to ${status}`);
      setSelectedPayroll(null);
      loadPayrollData();
    } catch (error) {
      console.error('Failed to update payroll status:', error);
      toast.error('Failed to update payroll status');
    }
  };
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount);
  };
  
  // Format date range
  const formatDateRange = (start: string, end: string) => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    
    return `${startDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
  };

  // Load data on component mount
  useEffect(() => {
    loadPayrollData();
    loadEmployees();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Payroll</h2>
          <p className="text-muted-foreground">Manage employee compensation and payroll processing.</p>
        </div>
        <button 
          onClick={() => setShowNewPayrollModal(true)}
          className="inline-flex h-10 items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
        >
          New Payroll
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Total Payroll</span>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-bold">{formatCurrency(totalPayroll)}</span>
            <div className="mt-1 flex items-center text-sm">
              <span className="text-green-500 mr-1">+5%</span>
              <span className="text-muted-foreground">vs. last month</span>
            </div>
          </div>
        </div>
        
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Pending Payments</span>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-bold">{pendingPayments}</span>
            <div className="mt-1 flex items-center text-sm">
              <span className="text-red-500 mr-1">+1</span>
              <span className="text-muted-foreground">vs. last month</span>
            </div>
          </div>
        </div>
        
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Average Salary</span>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-bold">{formatCurrency(averageSalary)}</span>
            <div className="mt-1 flex items-center text-sm">
              <span className="text-green-500 mr-1">+3%</span>
              <span className="text-muted-foreground">vs. last month</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Payroll table */}
      <div>
        <h3 className="mb-4 text-xl font-semibold">Recent Payroll</h3>
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent"></div>
          </div>
        ) : (
          <div className="rounded-lg border bg-card shadow-sm">
            <div className="p-4">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="pb-3 text-left font-medium">Employee</th>
                    <th className="pb-3 text-left font-medium">Period</th>
                    <th className="pb-3 text-left font-medium">Base Salary</th>
                    <th className="pb-3 text-left font-medium">Net Pay</th>
                    <th className="pb-3 text-left font-medium">Status</th>
                    <th className="pb-3 text-left font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {payrolls.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-4 text-center text-muted-foreground">No payroll records found</td>
                    </tr>
                  ) : (
                    payrolls.map((record) => (
                      <tr key={record.id} className="border-b last:border-0">
                        <td className="py-3">{record.employee_name}</td>
                        <td className="py-3">{formatDateRange(record.pay_period_start, record.pay_period_end)}</td>
                        <td className="py-3">{formatCurrency(record.base_salary)}</td>
                        <td className="py-3">{formatCurrency(record.net_pay)}</td>
                        <td className="py-3">
                          <span className={`rounded-full px-2 py-1 text-xs ${
                            record.status === 'paid' 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-amber-100 text-amber-800'
                          }`}>
                            {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                          </span>
                        </td>
                        <td className="py-3">
                          <button
                            onClick={() => setSelectedPayroll(record)}
                            className="text-sm text-primary hover:underline"
                          >
                            View
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
      
      {/* New Payroll Modal */}
      {showNewPayrollModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">New Payroll Record</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Employee</label>
                <select 
                  name="employee_id" 
                  value={newPayroll.employee_id}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting}
                >
                  <option value="">Select Employee</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>{emp.name}</option>
                  ))}
                </select>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Start Date</label>
                  <input 
                    type="date" 
                    name="pay_period_start"
                    value={newPayroll.pay_period_start}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded-md"
                    disabled={isSubmitting}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">End Date</label>
                  <input 
                    type="date"
                    name="pay_period_end" 
                    value={newPayroll.pay_period_end}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded-md"
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Base Salary</label>
                <input 
                  type="number"
                  name="base_salary"
                  value={newPayroll.base_salary}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="0.00"
                  disabled={isSubmitting}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Overtime</label>
                  <input 
                    type="number"
                    name="overtime"
                    value={newPayroll.overtime}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded-md"
                    placeholder="0.00"
                    disabled={isSubmitting}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Deductions</label>
                  <input 
                    type="number"
                    name="deductions"
                    value={newPayroll.deductions}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded-md"
                    placeholder="0.00"
                    disabled={isSubmitting}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Net Pay (Auto-calculated)</label>
                <input 
                  type="number"
                  name="net_pay"
                  value={newPayroll.net_pay}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  placeholder="0.00"
                  disabled={isSubmitting}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Status</label>
                <select 
                  name="status"
                  value={newPayroll.status}
                  onChange={handleInputChange}
                  className="w-full p-2 border rounded-md"
                  disabled={isSubmitting}
                >
                  <option value="pending">Pending</option>
                  <option value="paid">Paid</option>
                </select>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4 border-t">
                <button 
                  onClick={() => setShowNewPayrollModal(false)}
                  className="px-3 py-1 text-sm border rounded"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
                <button 
                  onClick={handleCreatePayroll}
                  className="px-3 py-1 text-sm bg-primary text-primary-foreground rounded"
                  disabled={isSubmitting || !newPayroll.employee_id || !newPayroll.pay_period_start || 
                           !newPayroll.pay_period_end || !newPayroll.base_salary}
                >
                  {isSubmitting ? 'Creating...' : 'Create Payroll'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Payroll detail modal */}
      {selectedPayroll && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-background rounded-lg shadow-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4">Payroll Details</h3>
            
            <div className="space-y-4">
              <div>
                <span className="block text-sm font-medium mb-1">Employee</span>
                <span className="block">{selectedPayroll.employee_name}</span>
              </div>
              
              <div>
                <span className="block text-sm font-medium mb-1">Pay Period</span>
                <span className="block">{formatDateRange(selectedPayroll.pay_period_start, selectedPayroll.pay_period_end)}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="block text-sm font-medium mb-1">Base Salary</span>
                  <span className="block">{formatCurrency(selectedPayroll.base_salary)}</span>
                </div>
                <div>
                  <span className="block text-sm font-medium mb-1">Overtime</span>
                  <span className="block">{formatCurrency(selectedPayroll.overtime)}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="block text-sm font-medium mb-1">Deductions</span>
                  <span className="block">{formatCurrency(selectedPayroll.deductions)}</span>
                </div>
                <div>
                  <span className="block text-sm font-medium mb-1">Net Pay</span>
                  <span className="block font-semibold">{formatCurrency(selectedPayroll.net_pay)}</span>
                </div>
              </div>
              
              <div>
                <span className="block text-sm font-medium mb-1">Status</span>
                <span className={`inline-block rounded-full px-2 py-1 text-xs ${
                  selectedPayroll.status === 'paid' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {selectedPayroll.status.charAt(0).toUpperCase() + selectedPayroll.status.slice(1)}
                </span>
              </div>
              
              <div className="flex justify-end space-x-2 pt-4 border-t">
                {selectedPayroll.status === 'pending' && (
                  <button 
                    className="px-3 py-1 text-sm bg-green-500 text-white rounded"
                    onClick={() => handleUpdateStatus(selectedPayroll.id, 'paid')}
                  >
                    Mark as Paid
                  </button>
                )}
                <button 
                  onClick={() => setSelectedPayroll(null)}
                  className="px-3 py-1 text-sm border rounded"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 
# HRMS Backend

A Flask-based backend API for the Human Resource Management System.

## Setup Instructions

1. **Create and activate a virtual environment**

```bash
# On Windows
python -m venv venv
venv\Scripts\activate

# On macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

2. **Install dependencies**

```bash
pip install -r requirements.txt
```

3. **Create a .env file**

Create a `.env` file in the backend directory with the following content:

```
SECRET_KEY=your_flask_secret_key
JWT_SECRET_KEY=your_jwt_secret_key
DATABASE_URL=sqlite:///hrms.db
JWT_ACCESS_TOKEN_EXPIRES=3600
JWT_REFRESH_TOKEN_EXPIRES=2592000
FLASK_APP=run.py
FLASK_ENV=development
```

4. **Initialize the database**

```bash
python init_db.py
```

This will create the database and populate it with initial test data:
- Admin user: admin@example.com / adminpassword
- Regular user: user@example.com / userpassword

5. **Run the server**

```bash
python run.py
```

The API will be available at http://localhost:5000

## API Endpoints

### Authentication

- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Log in a user
- `POST /api/auth/logout` - Log out a user
- `GET /api/auth/me` - Get current authenticated user
- `POST /api/auth/refresh` - Refresh access token

### Employees

- `GET /api/employees/` - Get all employees


### Leave

- `GET /api/leave/` - Get all leave requests

### Payroll

- `GET /api/payroll/` - Get all payroll records 
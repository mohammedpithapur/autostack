import os
from dotenv import load_dotenv
from app import create_app, db
from app.models import User, Department, Employee
from datetime import date

# Load environment variables from .env file
load_dotenv()

app = create_app()
app_context = app.app_context()
app_context.push()

def init_db():
    """Initialize the database with some data for testing."""
    # Create tables
    db.create_all()
    
    print("Created database tables")
    
    # Create departments if they don't exist
    eng_dept = Department.query.filter_by(name='Engineering').first()
    if not eng_dept:
        eng_dept = Department(name='Engineering', description='Software development and engineering')
        db.session.add(eng_dept)
    
    hr_dept = Department.query.filter_by(name='Human Resources').first()
    if not hr_dept:
        hr_dept = Department(name='Human Resources', description='Human resources management')
        db.session.add(hr_dept)
        
    marketing_dept = Department.query.filter_by(name='Marketing').first()
    if not marketing_dept:
        marketing_dept = Department(name='Marketing', description='Marketing and sales')
        db.session.add(marketing_dept)
    
    finance_dept = Department.query.filter_by(name='Finance').first()
    if not finance_dept:
        finance_dept = Department(name='Finance', description='Financial management and accounting')
        db.session.add(finance_dept)
        
    db.session.commit()
    
    # Check if admin user already exists
    admin_user = User.query.filter_by(email='admin@example.com').first()
    if not admin_user:
        # Create admin user
        admin_user = User(email='admin@example.com', name='Admin User', role='admin')
        admin_user.set_password('adminpassword')
        db.session.add(admin_user)
        db.session.commit()
        print("Created admin user: admin@example.com / adminpassword")
    
    # Check if admin has an employee record
    admin_employee = Employee.query.filter_by(user_id=admin_user.id).first()
    if not admin_employee:
        # Create employee for admin user
        admin_employee = Employee(
            user_id=admin_user.id,
            department_id=hr_dept.id,
            position='HR Manager',
            hire_date=date(2020, 1, 15),
            salary=85000.0,
            phone='(555) 123-4567',
            address='123 Admin St, Company HQ'
        )
        db.session.add(admin_employee)
        print("Created employee record for admin user")
    
    # Create or get regular user
    user = User.query.filter_by(email='user@example.com').first()
    if not user:
        user = User(email='user@example.com', name='Regular User', role='employee')
        user.set_password('userpassword')
        db.session.add(user)
        db.session.commit()
        print("Created regular user: user@example.com / userpassword")
    
    # Check if regular user has an employee record
    user_employee = Employee.query.filter_by(user_id=user.id).first()
    if not user_employee:
        # Create employee for regular user
        user_employee = Employee(
            user_id=user.id,
            department_id=eng_dept.id,
            position='Software Engineer',
            hire_date=date(2021, 3, 10),
            salary=75000.0,
            phone='(555) 987-6543',
            address='456 Developer Ave, Tech Town'
        )
        db.session.add(user_employee)
        print("Created employee record for regular user")
    
    # Add more test users and employees if they don't exist
    test_users = [
        {
            'email': 'jane.doe@example.com',
            'name': 'Jane Doe',
            'password': 'password123',
            'department_id': marketing_dept.id,
            'position': 'Marketing Specialist',
            'hire_date': date(2022, 2, 15),
            'salary': 65000.0
        },
        {
            'email': 'john.smith@example.com',
            'name': 'John Smith',
            'password': 'password123',
            'department_id': eng_dept.id,
            'position': 'Senior Developer',
            'hire_date': date(2019, 5, 20),
            'salary': 95000.0
        },
        {
            'email': 'sarah.johnson@example.com',
            'name': 'Sarah Johnson',
            'password': 'password123',
            'department_id': finance_dept.id,
            'position': 'Accountant',
            'hire_date': date(2020, 8, 1),
            'salary': 72000.0
        }
    ]
    
    for user_data in test_users:
        test_user = User.query.filter_by(email=user_data['email']).first()
        if not test_user:
            test_user = User(
                email=user_data['email'],
                name=user_data['name'],
                role='employee'
            )
            test_user.set_password(user_data['password'])
            db.session.add(test_user)
            db.session.commit()
            print(f"Created test user: {user_data['email']} / password123")
            
        # Check if test user has an employee record
        test_employee = Employee.query.filter_by(user_id=test_user.id).first()
        if not test_employee:
            test_employee = Employee(
                user_id=test_user.id,
                department_id=user_data['department_id'],
                position=user_data['position'],
                hire_date=user_data['hire_date'],
                salary=user_data['salary'],
                phone='(555) 123-0000',
                address='789 Employee St, Work City'
            )
            db.session.add(test_employee)
            print(f"Created employee record for {user_data['name']}")
    
    # Ensure all users have employee records
    for user in User.query.all():
        employee = Employee.query.filter_by(user_id=user.id).first()
        if not employee:
            # Default to Engineering department if none specified
            employee = Employee(
                user_id=user.id,
                department_id=eng_dept.id,
                position='Staff Member',
                hire_date=date.today(),
                salary=60000.0
            )
            db.session.add(employee)
            print(f"Created missing employee record for user {user.email}")
    
    db.session.commit()
    print("Database initialization complete")

if __name__ == '__main__':
    init_db() 
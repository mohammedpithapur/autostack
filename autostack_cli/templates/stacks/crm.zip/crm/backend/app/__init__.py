import os
from flask import Flask, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize SQLAlchemy with no specific settings yet
db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()

def create_app():
    """Application factory pattern."""
    app = Flask(__name__, static_folder=None)
    
    # Configure the Flask app
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev'),
        SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL', 'sqlite:///hrms.db'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        JWT_SECRET_KEY=os.environ.get('JWT_SECRET_KEY', 'dev-jwt-key'),
        JWT_ACCESS_TOKEN_EXPIRES=int(os.environ.get('JWT_ACCESS_TOKEN_EXPIRES', 3600)),  # 1 hour
        JWT_REFRESH_TOKEN_EXPIRES=int(os.environ.get('JWT_REFRESH_TOKEN_EXPIRES', 2592000)),  # 30 days
        JWT_TOKEN_LOCATION=['cookies'],
        JWT_COOKIE_SECURE=False,  # Set to True in production with HTTPS
        JWT_COOKIE_CSRF_PROTECT=False,  # Disabled for now for easier development
        JWT_CSRF_IN_COOKIES=True,
    )
    
    # Enable CORS
    CORS(app, supports_credentials=True)
    
    # Initialize extensions with app
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    
    # Import models
    from app.models import User, Department, Employee, Leave, Payroll
    
    # Register blueprints
    from app.api.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    
    from app.api.employees import bp as employees_bp
    app.register_blueprint(employees_bp, url_prefix='/api/employees')
    
    from app.api.leave import bp as leave_bp
    app.register_blueprint(leave_bp, url_prefix='/api/leave')
    
    from app.api.payroll import bp as payroll_bp
    app.register_blueprint(payroll_bp, url_prefix='/api/payroll')
    
    # Add dashboard endpoint for frontend to use
    @app.route('/api/dashboard/')
    def dashboard_stats():
        # Return mock dashboard data
        return jsonify({
            "stats": {
                "total_employees": 245,
                "present_today": 198,
                "on_leave": 24,
                "open_positions": 12
            },
            "activities": [
                {
                    "id": 1,
                    "name": "John Smith",
                    "action": "Requested leave from 15th to 18th May",
                    "timestamp": "2 hours ago",
                    "status": "approved"
                },
                {
                    "id": 2,
                    "name": "Emily Johnson",
                    "action": "Clocked in late",
                    "timestamp": "3 hours ago",
                    "status": "pending"
                },
                {
                    "id": 3,
                    "name": "Michael Williams",
                    "action": "Requested equipment purchase",
                    "timestamp": "5 hours ago",
                    "status": "rejected"
                },
                {
                    "id": 4,
                    "name": "Sarah Davis",
                    "action": "Completed onboarding",
                    "timestamp": "1 day ago",
                    "status": "approved"
                },
                {
                    "id": 5,
                    "name": "James Rodriguez",
                    "action": "Updated personal information",
                    "timestamp": "1 day ago",
                    "status": "approved"
                }
            ]
        })
    
    # Add handlers for endpoints that the frontend might request from POS/CRM template
    @app.route('/api/products/')
    def products_redirect():
        # Redirect products to employees data
        return jsonify({"message": "Products API not available in HRMS. Please use /api/employees/ endpoint."}), 200
    
    @app.route('/api/sales/')
    def sales_redirect():
        # Redirect sales to payroll data
        return jsonify({"message": "Sales API not available in HRMS. Please use /api/payroll/ endpoint."}), 200
    
    @app.route('/api/customers/')
    def customers_redirect():
        # Redirect customers to employees data
        return jsonify({"message": "Customers API not available in HRMS. Please use /api/employees/ endpoint."}), 200
    
    @app.route('/api/health')
    def health_check():
        return {"status": "ok"}, 200
    
    return app 
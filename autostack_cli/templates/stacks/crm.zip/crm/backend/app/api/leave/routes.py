from flask import jsonify, request, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
from app.api.leave import bp
from app import db
from app.models import Leave, Employee, User, Department

@bp.route('/', methods=['GET'])
@jwt_required()
def get_leaves():
    """Get leave requests with pagination."""
    # Simple stub for now
    leaves = Leave.query.all()
    
    # Count leaves by status
    pending_count = sum(1 for leave in leaves if leave.status == 'pending')
    approved_count = sum(1 for leave in leaves if leave.status == 'approved')
    rejected_count = sum(1 for leave in leaves if leave.status == 'rejected')
    
    # Group leaves by status
    leaves_by_status = {
        'pending': [leave.to_dict() for leave in leaves if leave.status == 'pending'],
        'approved': [leave.to_dict() for leave in leaves if leave.status == 'approved'],
        'rejected': [leave.to_dict() for leave in leaves if leave.status == 'rejected']
    }
    
    return jsonify({
        "leave_requests": [leave.to_dict() for leave in leaves],
        "leaves_by_status": leaves_by_status,
        "pending_count": pending_count,
        "approved_count": approved_count,
        "rejected_count": rejected_count,
        "total": len(leaves)
    })

@bp.route('/', methods=['POST'])
@jwt_required()
def create_leave():
    """Create a new leave request."""
    data = request.get_json()
    user_id = get_jwt_identity()
    
    # Validate required fields
    if not all(k in data for k in ('start_date', 'end_date', 'leave_type')):
        return jsonify({"message": "Missing required fields"}), 400
    
    try:
        # Get the user
        user = User.query.get(user_id)
        if not user:
            return jsonify({"message": "User not found"}), 404
            
        # Get employee record
        employee = Employee.query.filter_by(user_id=user_id).first()
        
        if not employee:
            return jsonify({"message": "Employee record not found"}), 404
        
        # Parse dates from strings
        start_date = datetime.fromisoformat(data['start_date'].replace('Z', '+00:00'))
        end_date = datetime.fromisoformat(data['end_date'].replace('Z', '+00:00'))
        
        # Create new leave request
        leave = Leave(
            employee_id=employee.id,
            start_date=start_date.date(),
            end_date=end_date.date(),
            leave_type=data['leave_type'],
            reason=data.get('reason', ''),
            status='pending'
        )
        
        db.session.add(leave)
        db.session.commit()
        
        return jsonify({
            "message": "Leave request created successfully",
            "leave": leave.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"An error occurred: {str(e)}")
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:leave_id>', methods=['PUT'])
@jwt_required()
def update_leave(leave_id):
    """Update a leave request."""
    data = request.get_json()
    user_id = get_jwt_identity()
    
    # Find the leave request
    leave = Leave.query.get(leave_id)
    if not leave:
        return jsonify({"message": "Leave request not found"}), 404
    
    try:
        # Update leave request fields
        if 'status' in data:
            leave.status = data['status']
            if data['status'] == 'approved':
                leave.approved_by = user_id
            
        if 'leave_type' in data:
            leave.leave_type = data['leave_type']
            
        if 'reason' in data:
            leave.reason = data['reason']
            
        if 'start_date' in data:
            leave.start_date = datetime.fromisoformat(data['start_date'].replace('Z', '+00:00')).date()
            
        if 'end_date' in data:
            leave.end_date = datetime.fromisoformat(data['end_date'].replace('Z', '+00:00')).date()
        
        db.session.commit()
        
        return jsonify({
            "message": "Leave request updated successfully",
            "leave": leave.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500

@bp.route('/<int:leave_id>', methods=['DELETE'])
@jwt_required()
def delete_leave(leave_id):
    """Delete a leave request."""
    # Find the leave request
    leave = Leave.query.get(leave_id)
    if not leave:
        return jsonify({"message": "Leave request not found"}), 404
    
    try:
        db.session.delete(leave)
        db.session.commit()
        
        return jsonify({
            "message": "Leave request deleted successfully"
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"An error occurred: {str(e)}"}), 500 
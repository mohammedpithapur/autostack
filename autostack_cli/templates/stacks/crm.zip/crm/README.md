# HRMS - Human Resource Management System

A full-stack Human Resource Management System with React frontend and Flask backend.

## Project Structure

```
react-flask-hrms/
├── frontend/             # React + Vite frontend
│   ├── src/              # React source code
│   │   ├── contexts/     # React contexts (auth, etc.)
│   │   ├── hooks/        # Custom React hooks
│   │   ├── layouts/      # Page layouts
│   │   └── pages/        # React pages/components
│   └── ...               # Frontend configuration files
│
└── backend/              # Flask backend
    ├── app/              # Flask application
    │   ├── api/          # API endpoints
    │   │   ├── auth/     # Authentication routes
    │   │   └── ...       # Other API modules
    │   └── models.py     # Database models
    └── ...               # Backend configuration files
```

## Features

- User authentication (register, login, logout)
- Employee management
- Attendance tracking
- Leave management
- Payroll processing
- Role-based access control

## Getting Started

### Running the Backend

See [Backend README](backend/README.md) for detailed instructions.

1. Create and activate a Python virtual environment
2. Install backend dependencies
3. Set up environment variables
4. Initialize the database
5. Run the Flask server

### Running the Frontend

1. Navigate to the frontend directory:

```bash
cd frontend
```

2. Install dependencies:

```bash
npm install
```

3. Start the development server:

```bash
npm run dev
```

The React application will be available at http://localhost:5173

## Test Accounts

- Admin: admin@example.com / adminpassword
- User: user@example.com / userpassword 
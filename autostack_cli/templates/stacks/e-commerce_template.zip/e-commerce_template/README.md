# E-Commerce Store Application

A full-stack e-commerce application built with React frontend and Flask backend with SQLite database.

## Project Structure

```
react-flask-ecommerce/
├── frontend/             # React + Vite frontend
│   ├── src/              # React source code
│   │   ├── components/   # React components
│   │   │   ├── layout/   # Layout components (header, footer, etc.)
│   │   │   ├── products/ # Product-related components
│   │   │   └── auth/     # Authentication components
│   │   ├── contexts/     # React contexts (auth, cart, etc.)
│   │   ├── hooks/        # Custom React hooks
│   │   ├── layouts/      # Page layouts
│   │   └── pages/        # React pages
│   └── ...               # Frontend configuration files
│
└── backend/              # Flask backend
    ├── app/              # Flask application
    │   ├── api/          # API endpoints
    │   │   ├── auth/     # Authentication routes
    │   │   ├── products/ # Product routes
    │   │   ├── cart/     # Cart routes
    │   │   └── orders/   # Order routes
    │   └── models.py     # Database models
    └── ...               # Backend configuration files
```

## Features

- User authentication (register, login, logout)
- Product catalog with categories
- Shopping cart functionality
- Order placement and history
- Product search and filtering
- Responsive design for desktop and mobile

## Getting Started

### Running the Backend

1. Create and activate a Python virtual environment
2. Install backend dependencies
3. Initialize the database
4. Run the Flask server

```bash
cd backend
pip install -r requirements.txt
python init_db.py
python run.py
```

### Running the Frontend

1. Navigate to the frontend directory:

```bash
cd frontend
```

2. Install dependencies:

```bash
npm install
```

3. Start the development server:

```bash
npm run dev
```

The React application will be available at http://localhost:5173

## Test Accounts

- Admin: admin@example.com / adminpassword
- User: user@example.com / userpassword 
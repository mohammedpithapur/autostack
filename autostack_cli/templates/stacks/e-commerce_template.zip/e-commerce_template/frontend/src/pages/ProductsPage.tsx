import React, { useState } from 'react';
import ProductCard from '../components/products/ProductCard';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { Search, Filter } from 'lucide-react';

type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
};

// Mock product data
const mockProducts: Product[] = [
  {
    id: 1,
    name: 'Premium Wireless Headphones',
    description: 'High-fidelity wireless headphones with active noise cancellation and 30-hour battery life.',
    price: 299.99,
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
    category: 'Electronics'
  },
  {
    id: 2,
    name: 'Smart Watch Pro',
    description: 'Advanced fitness tracking, heart rate monitoring, and smartphone notifications in a stylish design.',
    price: 249.99,
    image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 3,
    name: 'Classic Leather Backpack',
    description: 'Handcrafted genuine leather backpack with laptop compartment and premium hardware.',
    price: 159.99,
    image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  {
    id: 4,
    name: 'Minimalist Watch',
    description: 'Elegant timepiece with Japanese movement and sapphire crystal glass.',
    price: 199.99,
    image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  {
    id: 5,
    name: 'Portable Bluetooth Speaker',
    description: 'Waterproof speaker with 24-hour battery life and rich, immersive sound.',
    price: 89.99,
    image_url: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 6,
    name: 'Ergonomic Office Chair',
    description: 'Adjustable chair with lumbar support and breathable mesh backrest.',
    price: 349.99,
    image_url: 'https://images.unsplash.com/photo-1596079890744-c1a0462d0975?w=800&auto=format&fit=crop',
    category: 'Home'
  },
  {
    id: 7,
    name: 'Digital Camera Kit',
    description: 'Professional DSLR camera with 24-70mm lens and accessories.',
    price: 1299.99,
    image_url: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 8,
    name: 'Wireless Earbuds',
    description: 'True wireless earbuds with noise isolation and compact charging case.',
    price: 129.99,
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
    category: 'Electronics'
  }
];

// Get unique categories from mock data
const mockCategories = Array.from(new Set(mockProducts.map(p => p.category))).filter(Boolean) as string[];

export default function ProductsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  
  // Filter products based on search term and category
  const filteredProducts = mockProducts.filter(product => {
    const matchesSearch = searchTerm === '' || 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase());
      
    const matchesCategory = selectedCategory === '' || product.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-6">All Products</h1>
          
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            {/* Search Bar */}
            <div className="relative flex-grow">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            
            {/* Category Filter */}
            <div className="relative w-full md:w-64">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary appearance-none"
              >
                <option value="">All Categories</option>
                {mockCategories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
                <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

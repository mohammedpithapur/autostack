import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ShoppingCart, ArrowLeft, Plus, Minus } from 'lucide-react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { useCart } from '../hooks/useCart';
import { useAuth } from '../hooks/useAuth';

type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
};

const mockProducts: Product[] = [
  {
    id: 1,
    name: 'Premium Wireless Headphones',
    description: 'High-fidelity wireless headphones with active noise cancellation and 30-hour battery life.',
    price: 299.99,
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
    category: 'Electronics'
  },
  {
    id: 2,
    name: 'Smart Watch Pro',
    description: 'Advanced fitness tracking, heart rate monitoring, and smartphone notifications in a stylish design.',
    price: 249.99,
    image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 3,
    name: 'Classic Leather Backpack',
    description: 'Handcrafted genuine leather backpack with laptop compartment and premium hardware.',
    price: 159.99,
    image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  {
    id: 4,
    name: 'Minimalist Watch',
    description: 'Elegant timepiece with Japanese movement and sapphire crystal glass.',
    price: 199.99,
    image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  {
    id: 5,
    name: 'Portable Bluetooth Speaker',
    description: 'Waterproof speaker with 24-hour battery life and rich, immersive sound.',
    price: 89.99,
    image_url: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 6,
    name: 'Ergonomic Office Chair',
    description: 'Adjustable chair with lumbar support and breathable mesh backrest.',
    price: 349.99,
    image_url: 'https://images.unsplash.com/photo-1596079890744-c1a0462d0975?w=800&auto=format&fit=crop',
    category: 'Home'
  },
  {
    id: 7,
    name: 'Digital Camera Kit',
    description: 'Professional DSLR camera with 24-70mm lens and accessories.',
    price: 1299.99,
    image_url: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 8,
    name: 'Wireless Earbuds',
    description: 'True wireless earbuds with noise isolation and compact charging case.',
    price: 129.99,
    image_url: 'https://images.unsplash.com/photo-1588024531955-585c39c8f38a?w=800&auto=format&fit=crop',
    category: 'Electronics'
  }
];

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const product = mockProducts.find(p => p.id === Number(id));
  const [quantity, setQuantity] = useState(1);
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();
  const [addingToCart, setAddingToCart] = useState(false);
  const [addedToCart, setAddedToCart] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              Product not found
            </h2>
            <Link to="/products" className="text-primary hover:underline flex items-center justify-center">
              <ArrowLeft className="mr-2" size={16} />
              Back to Products
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const handleQuantityChange = (value: number) => {
    if (value >= 1) {
      setQuantity(value);
    }
  };

  const handleAddToCart = async () => {
    if (!product) return;
    if (!isAuthenticated) {
      window.location.href = '/auth/login';
      return;
    }
    try {
      setAddingToCart(true);
      await addToCart(product.id, quantity);
      setAddedToCart(true);
      setTimeout(() => setAddedToCart(false), 3000);
    } catch (error) {
      console.error('Failed to add to cart:', error);
    } finally {
      setAddingToCart(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link to="/products" className="text-primary hover:underline flex items-center">
            <ArrowLeft className="mr-2" size={16} />
            Back to Products
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="rounded-lg overflow-hidden bg-gray-100">
            <img 
              src={product.image_url} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>
          {/* Product Details */}
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">{product.name}</h1>
            <p className="text-sm text-gray-500 mb-4">Category: {product.category}</p>
            <p className="text-2xl font-bold text-primary mb-6">${product.price.toFixed(2)}</p>
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-gray-700">{product.description}</p>
            </div>
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Quantity</h3>
              <div className="flex items-center">
                <button 
                  onClick={() => handleQuantityChange(quantity - 1)}
                  disabled={quantity <= 1}
                  className="p-2 border border-gray-300 rounded-l-md hover:bg-gray-100 disabled:opacity-50"
                >
                  <Minus size={16} />
                </button>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                  className="w-16 text-center border-y border-gray-300 py-2 focus:outline-none"
                />
                <button 
                  onClick={() => handleQuantityChange(quantity + 1)}
                  className="p-2 border border-gray-300 rounded-r-md hover:bg-gray-100"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>
            <button
              onClick={handleAddToCart}
              disabled={addingToCart}
              className={`w-full py-3 px-4 rounded-md flex items-center justify-center transition-colors ${
                addedToCart 
                  ? 'bg-green-600 text-white' 
                  : 'bg-primary text-white hover:bg-primary-dark'
              } disabled:opacity-50`}
            >
              {addingToCart ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
              ) : addedToCart ? (
                'Added to Cart!'
              ) : (
                <>
                  <ShoppingCart className="mr-2" size={18} />
                  Add to Cart
                </>
              )}
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
} 
import React from 'react';
import HeroSection from '../components/layout/HeroSection';
import ProductCard from '../components/products/ProductCard';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { Link } from 'react-router-dom';

type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
};

// Featured mock products
const featuredProducts: Product[] = [
  {
    id: 1,
    name: 'Premium Wireless Headphones',
    description: 'High-fidelity wireless headphones with active noise cancellation and 30-hour battery life.',
    price: 299.99,
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
    category: 'Electronics'
  },
  {
    id: 2,
    name: 'Smart Watch Pro',
    description: 'Advanced fitness tracking, heart rate monitoring, and smartphone notifications in a stylish design.',
    price: 249.99,
    image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  {
    id: 3,
    name: 'Classic Leather Backpack',
    description: 'Handcrafted genuine leather backpack with laptop compartment and premium hardware.',
    price: 159.99,
    image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  {
    id: 4,
    name: 'Minimalist Watch',
    description: 'Elegant timepiece with Japanese movement and sapphire crystal glass.',
    price: 199.99,
    image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop',
    category: 'Accessories'
  }
];

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <HeroSection />
        
        {/* Featured Products Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Latest Products</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
            
            <div className="text-center mt-12">
              <Link 
                to="/products" 
                className="bg-white text-primary border border-primary px-6 py-3 rounded-md hover:bg-gray-50"
              >
                View All Products
              </Link>
            </div>
          </div>
        </section>
        
        {/* Categories Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Shop by Category</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <Link to="/products?category=electronics" className="block h-full">
                  <div className="aspect-video relative">
                    <img 
                      src="https://images.unsplash.com/photo-1618166080964-cdb5843979b0?fm=jpg" 
                      alt="Electronics"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <h3 className="text-white text-2xl font-bold">Electronics</h3>
                    </div>
                  </div>
                </Link>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <Link to="/products?category=clothing" className="block h-full">
                  <div className="aspect-video relative">
                    <img 
                      src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=600&q=80" 
                      alt="Clothing"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <h3 className="text-white text-2xl font-bold">Clothing</h3>
                    </div>
                  </div>
                </Link>
              </div>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <Link to="/products?category=home" className="block h-full">
                  <div className="aspect-video relative">
                    <img 
                      src="https://images.unsplash.com/photo-1554295405-abb8fd54f153?w=600&q=80" 
                      alt="Home & Furniture"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                      <h3 className="text-white text-2xl font-bold">Home & Furniture</h3>
                    </div>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}

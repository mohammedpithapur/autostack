import { Link, Outlet } from 'react-router-dom';

export default function AuthLayout() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <div className="py-6">
        <Link to="/" className="flex justify-center">
          <span className="text-2xl font-bold text-primary">E-Commerce Store</span>
        </Link>
      </div>
      
      <div className="flex-grow flex items-center justify-center px-4">
        <div className="w-full max-w-md p-8 bg-white rounded-lg shadow-md">
          <Outlet />
        </div>
      </div>
      
      <footer className="py-6 text-center text-gray-500">
        <p>&copy; {new Date().getFullYear()} E-Commerce Store. All rights reserved.</p>
      </footer>
    </div>
  );
} 
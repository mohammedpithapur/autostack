import React, { createContext, useCallback, useEffect, useState, ReactNode } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { useAuth } from '../hooks/useAuth';

const API_URL = 'http://localhost:5000/api';

// Mock products data for reference
const mockProducts = {
  1: {
    id: 1,
    name: 'Premium Wireless Headphones',
    description: 'High-fidelity wireless headphones with active noise cancellation and 30-hour battery life.',
    price: 299.99,
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
    category: 'Electronics'
  },
  2: {
    id: 2,
    name: 'Smart Watch Pro',
    description: 'Advanced fitness tracking, heart rate monitoring, and smartphone notifications in a stylish design.',
    price: 249.99,
    image_url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  3: {
    id: 3,
    name: 'Classic Leather Backpack',
    description: 'Handcrafted genuine leather backpack with laptop compartment and premium hardware.',
    price: 159.99,
    image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  4: {
    id: 4,
    name: 'Minimalist Watch',
    description: 'Elegant timepiece with Japanese movement and sapphire crystal glass.',
    price: 199.99,
    image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop',
    category: 'Accessories'
  },
  5: {
    id: 5,
    name: 'Portable Bluetooth Speaker',
    description: 'Waterproof speaker with 24-hour battery life and rich, immersive sound.',
    price: 89.99,
    image_url: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  6: {
    id: 6,
    name: 'Ergonomic Office Chair',
    description: 'Adjustable chair with lumbar support and breathable mesh backrest.',
    price: 349.99,
    image_url: 'https://images.unsplash.com/photo-1596079890744-c1a0462d0975?w=800&auto=format&fit=crop',
    category: 'Home'
  },
  7: {
    id: 7,
    name: 'Digital Camera Kit',
    description: 'Professional DSLR camera with 24-70mm lens and accessories.',
    price: 1299.99,
    image_url: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&auto=format&fit=crop',
    category: 'Electronics'
  },
  8: {
    id: 8,
    name: 'Wireless Earbuds',
    description: 'True wireless earbuds with noise isolation and compact charging case.',
    price: 129.99,
    image_url: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
    category: 'Electronics'
  }
};

export type CartItem = {
  id: number;
  product_id: number;
  name: string;
  price: number;
  image_url: string;
  quantity: number;
};

type CartContextType = {
  cartItems: CartItem[];
  totalItems: number;
  totalPrice: number;
  isLoading: boolean;
  addToCart: (productId: number, quantity?: number) => Promise<void>;
  updateQuantity: (itemId: number, quantity: number) => Promise<void>;
  removeFromCart: (itemId: number) => Promise<void>;
  clearCart: () => Promise<void>;
  refreshCart: () => Promise<void>;
};

export const CartContext = createContext<CartContextType>({
  cartItems: [],
  totalItems: 0,
  totalPrice: 0,
  isLoading: false,
  addToCart: async () => {},
  updateQuantity: async () => {},
  removeFromCart: async () => {},
  clearCart: async () => {},
  refreshCart: async () => {},
});

export const CartProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { isAuthenticated } = useAuth();

  const totalItems = cartItems.reduce((total, item) => total + item.quantity, 0);
  const totalPrice = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);

  const refreshCart = useCallback(async () => {
    if (!isAuthenticated) {
      setCartItems([]);
      return;
    }
    setIsLoading(true);
    try {
      const response = await axios.get(`${API_URL}/cart/items`);
      const backendCartItems = response.data.cart_items.map((item: any) => {
        const product = mockProducts[item.product_id as keyof typeof mockProducts] || item.product;
        return {
          id: item.id,
          product_id: item.product_id,
          name: product.name,
          price: product.price,
          image_url: product.image_url,
          quantity: item.quantity,
        }
      });
      setCartItems(backendCartItems);
    } catch (error) {
      console.error('Failed to fetch cart:', error);
      setCartItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    refreshCart();
  }, [refreshCart]);

  const addToCart = async (productId: number, quantity: number = 1) => {
    if (!isAuthenticated) {
      toast.error("Please log in to add items to your cart.");
      return;
    }
    setIsLoading(true);
    try {
      await axios.post(`${API_URL}/cart/add`, { product_id: productId, quantity });
      await refreshCart();
      toast.success("Item added to cart");
    } catch (error) {
      console.error('Failed to add item to cart:', error);
      toast.error("Failed to add item to cart.");
    } finally {
      setIsLoading(false);
    }
  };

  const updateQuantity = async (itemId: number, quantity: number) => {
    if (quantity <= 0) {
      return removeFromCart(itemId);
    }
    setIsLoading(true);
    try {
      await axios.put(`${API_URL}/cart/update/${itemId}`, { quantity });
      await refreshCart();
      toast.success("Cart updated");
    } catch (error) {
      console.error('Failed to update cart:', error);
      toast.error("Failed to update cart.");
    } finally {
      setIsLoading(false);
    }
  };

  const removeFromCart = async (itemId: number) => {
    setIsLoading(true);
    try {
      await axios.delete(`${API_URL}/cart/remove/${itemId}`);
      await refreshCart();
      toast.success("Item removed from cart");
    } catch (error) {
      console.error('Failed to remove item from cart:', error);
      toast.error("Failed to remove item from cart.");
    } finally {
      setIsLoading(false);
    }
  };

  const clearCart = async () => {
    setIsLoading(true);
    try {
      await axios.delete(`${API_URL}/cart/clear`);
      setCartItems([]);
      toast.success("Cart cleared");
    } catch (error) {
      console.error('Failed to clear cart:', error);
      toast.error("Failed to clear cart.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        totalItems,
        totalPrice,
        isLoading,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        refreshCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

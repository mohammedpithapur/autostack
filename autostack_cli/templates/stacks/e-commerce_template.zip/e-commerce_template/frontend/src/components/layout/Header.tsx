import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useCart } from '../../hooks/useCart';
import { ShoppingCart, User, Menu, X } from 'lucide-react';

export default function Header() {
  const { isAuthenticated, user, logout } = useAuth();
  const { totalItems } = useCart();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  const handleLogout = async () => {
    try {
      await logout();
      // Redirect happens automatically via AuthContext and protected routes
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <header className="bg-white shadow">
      <div className="container mx-auto px-4 py-4">
        <nav className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="text-2xl font-bold text-primary">
            E-Store
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-primary">
              Home
            </Link>
            <Link to="/products" className="text-gray-700 hover:text-primary">
              Products
            </Link>
            {isAuthenticated ? (
              <>
                <div className="relative">
                  <Link to="/account/cart" className="text-gray-700 hover:text-primary">
                    <ShoppingCart className="w-5 h-5" />
                    {totalItems > 0 && (
                      <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                        {totalItems}
                      </span>
                    )}
                  </Link>
                </div>
                <div className="relative">
                  <button 
                    className="flex items-center text-gray-700 hover:text-primary"
                    onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                  >
                    <User className="w-5 h-5 mr-1" />
                    {user?.name.split(' ')[0]}
                  </button>
                  {isProfileMenuOpen && (
                    <div 
                      className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-10"
                      onMouseLeave={() => setIsProfileMenuOpen(false)}
                    >
                      <Link 
                        to="/account/profile" 
                        className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                        onClick={() => setIsProfileMenuOpen(false)}
                      >
                        Profile
                      </Link>
                      <button
                        onClick={() => {
                          handleLogout();
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                      >
                        Logout
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <Link to="/auth/login" className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark">
                Sign In
              </Link>
            )}
          </div>
          
          {/* Mobile menu button */}
          <button className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </nav>
        
        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4">
            <div className="flex flex-col space-y-4">
              <Link to="/" className="text-gray-700 hover:text-primary" onClick={toggleMenu}>
                Home
              </Link>
              <Link to="/products" className="text-gray-700 hover:text-primary" onClick={toggleMenu}>
                Products
              </Link>
              
              {isAuthenticated ? (
                <>
                  <Link to="/account/orders" className="text-gray-700 hover:text-primary" onClick={toggleMenu}>
                    My Orders
                  </Link>
                  <Link to="/account/cart" className="text-gray-700 hover:text-primary flex items-center" onClick={toggleMenu}>
                    <ShoppingCart className="w-5 h-5 mr-2" />
                    Cart {totalItems > 0 && `(${totalItems})`}
                  </Link>
                  <Link to="/account/profile" className="text-gray-700 hover:text-primary" onClick={toggleMenu}>
                    Profile
                  </Link>
                  <button
                    onClick={() => {
                      handleLogout();
                      toggleMenu();
                    }}
                    className="text-left text-gray-700 hover:text-primary"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link 
                  to="/auth/login" 
                  className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark inline-block"
                  onClick={toggleMenu}
                >
                  Sign In
                </Link>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
} 
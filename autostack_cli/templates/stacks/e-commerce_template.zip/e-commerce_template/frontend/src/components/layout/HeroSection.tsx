import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag } from 'lucide-react';

export default function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-gray-50 to-blue-50 py-20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-gray-800">
              Shop the Latest Products With Ease
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Discover our wide range of products at competitive prices.
              Fast shipping, secure payments, and excellent customer support.
            </p>
            <div className="flex space-x-4">
              <Link
                to="/products"
                className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition-colors flex items-center"
              >
                <ShoppingBag className="mr-2" />
                Shop Now
              </Link>
              <Link
                to="/auth/register"
                className="border border-gray-300 text-gray-700 px-6 py-3 rounded-md hover:bg-gray-100 transition-colors"
              >
                Sign Up
              </Link>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <img
              src="https://images.unsplash.com/photo-1607082349566-187342175e2f?w=800&q=80"
              alt="Shopping Experience"
              className="rounded-lg shadow-xl max-w-full h-auto"
              width={600}
              height={400}
            />
          </div>
        </div>
      </div>
    </section>
  );
} 
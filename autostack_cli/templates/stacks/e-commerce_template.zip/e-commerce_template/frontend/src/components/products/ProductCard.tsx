import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react';
import { useCart } from '../../hooks/useCart';
import { useAuth } from '../../hooks/useAuth';

type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
};

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();
  
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) {
      // Redirect to login
      window.location.href = '/auth/login';
      return;
    }
    
    try {
      await addToCart(product.id, 1);
    } catch (error) {
      console.error('Failed to add to cart:', error);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <Link to={`/products/${product.id}`}>
        <div className="aspect-square relative overflow-hidden">
          <img
            src={product.image_url}
            alt={product.name}
            className="object-cover w-full h-full hover:scale-105 transition-transform"
          />
        </div>
        
        <div className="p-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-1 truncate">{product.name}</h3>
          <p className="text-sm text-gray-600 mb-2 line-clamp-2 h-10">{product.description}</p>
          
          <div className="flex items-center justify-between mt-4">
            <span className="text-primary font-bold text-lg">${product.price.toFixed(2)}</span>
            <button
              onClick={handleAddToCart}
              className="bg-primary text-white px-6 py-2 rounded-md hover:bg-primary-dark flex items-center justify-center gap-2"
              aria-label="Add to cart"
            >
              <span>Add</span> <ShoppingCart size={16} />
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
}

import os
import random
from datetime import datetime
from app import create_app, db
from app.models import User, Category, Product

# Initialize app and context
app = create_app()
app.app_context().push()

def init_db():
    """Initialize the database with tables and sample data."""
    # Create tables
    db.create_all()
    print("Tables created.")
    
    # Create admin user if not exists
    if not User.query.filter_by(email='admin@example.com').first():
        admin = User(
            email='admin@example.com',
            name='Admin User',
            role='admin'
        )
        admin.set_password('adminpassword')
        db.session.add(admin)
        
        # Create regular user if not exists
        user = User(
            email='user@example.com',
            name='Regular User',
            role='customer'
        )
        user.set_password('userpassword')
        db.session.add(user)
        
        db.session.commit()
        print("Users created.")
    
    # Create categories if not exists
    categories = ['Electronics', 'Clothing', 'Home', 'Books', 'Sports']
    for cat_name in categories:
        if not Category.query.filter_by(name=cat_name).first():
            category = Category(
                name=cat_name,
                description=f"{cat_name} products and accessories."
            )
            db.session.add(category)
    
    db.session.commit()
    print("Categories created.")
    
    # Create sample products if not exists
    if Product.query.count() == 0:
        # Get category IDs
        electronics_cat = Category.query.filter_by(name='Electronics').first()
        accessories_cat = Category.query.filter_by(name='Accessories').first()
        home_cat = Category.query.filter_by(name='Home').first()

        # Create categories if they don't exist
        if not accessories_cat:
            accessories_cat = Category(name='Accessories', description='Gadgets and accessories')
            db.session.add(accessories_cat)
        if not home_cat:
            home_cat = Category(name='Home', description='Home goods')
            db.session.add(home_cat)
        
        db.session.commit()

        products = [
            {
                'id': 1, 'name': 'Premium Wireless Headphones', 'price': 299.99, 'stock': 50,
                'description': 'High-fidelity wireless headphones with active noise cancellation and 30-hour battery life.',
                'image_url': 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop',
                'category_id': electronics_cat.id, 'is_featured': True
            },
            {
                'id': 2, 'name': 'Smart Watch Pro', 'price': 249.99, 'stock': 30,
                'description': 'Advanced fitness tracking, heart rate monitoring, and smartphone notifications in a stylish design.',
                'image_url': 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop',
                'category_id': electronics_cat.id, 'is_featured': True
            },
            {
                'id': 3, 'name': 'Classic Leather Backpack', 'price': 159.99, 'stock': 20,
                'description': 'Handcrafted genuine leather backpack with laptop compartment and premium hardware.',
                'image_url': 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop',
                'category_id': accessories_cat.id, 'is_featured': False
            },
            {
                'id': 4, 'name': 'Minimalist Watch', 'price': 199.99, 'stock': 40,
                'description': 'Elegant timepiece with Japanese movement and sapphire crystal glass.',
                'image_url': 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800&auto=format&fit=crop',
                'category_id': accessories_cat.id, 'is_featured': False
            },
            {
                'id': 5, 'name': 'Portable Bluetooth Speaker', 'price': 89.99, 'stock': 100,
                'description': 'Waterproof speaker with 24-hour battery life and rich, immersive sound.',
                'image_url': 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&auto=format&fit=crop',
                'category_id': electronics_cat.id, 'is_featured': True
            },
            {
                'id': 6, 'name': 'Ergonomic Office Chair', 'price': 349.99, 'stock': 15,
                'description': 'Adjustable chair with lumbar support and breathable mesh backrest.',
                'image_url': 'https://images.unsplash.com/photo-1596079890744-c1a0462d0975?w=800&auto=format&fit=crop',
                'category_id': home_cat.id, 'is_featured': False
            },
            {
                'id': 7, 'name': 'Digital Camera Kit', 'price': 1299.99, 'stock': 10,
                'description': 'Professional DSLR camera with 24-70mm lens and accessories.',
                'image_url': 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=800&auto=format&fit=crop',
                'category_id': electronics_cat.id, 'is_featured': False
            },
            {
                'id': 8, 'name': 'Wireless Earbuds', 'price': 129.99, 'stock': 60,
                'description': 'True wireless earbuds with noise isolation and compact charging case.',
                'image_url': 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?fm=jpg',
                'category_id': electronics_cat.id, 'is_featured': True
            }
        ]
        
        for product_data in products:
            # Check if product with this ID already exists
            if not Product.query.get(product_data['id']):
                product = Product(**product_data)
                db.session.add(product)
        
        db.session.commit()
        print("Sample products created.")
    
    print("Database initialized successfully!")

if __name__ == '__main__':
    # Check if DB file exists
    db_path = os.path.join(app.instance_path, 'ecommerce.db')
    db_exists = os.path.exists(db_path)
    
    # Ensure instance path exists
    os.makedirs(app.instance_path, exist_ok=True)
    
    # Initialize the database
    init_db()
    
    print(f"Database location: {db_path}")
    if not db_exists:
        print("New database was created.")
    else:
        print("Existing database was updated.")

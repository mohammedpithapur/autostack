from flask import jsonify, request
from app.api.products import bp
from app.models import Product, Category

@bp.route('/', methods=['GET'])
def get_all_products():
    """Get all products with optional filtering."""
    # Return an empty array - we're using mock data in the frontend
    return jsonify({
        "products": [],
        "count": 0
    })

@bp.route('/featured', methods=['GET'])
def get_featured_products():
    """Get featured products."""
    # Return an empty array - we're using mock data in the frontend
    return jsonify({
        "products": [],
        "count": 0
    })

@bp.route('/<int:product_id>', methods=['GET'])
def get_product(product_id):
    """Get a specific product by ID."""
    # Return 404 - we're using mock data in the frontend
    return jsonify({"message": "Product not found"}), 404

@bp.route('/categories', methods=['GET'])
def get_categories():
    """Get all product categories."""
    # Return an empty array - we're using mock data in the frontend
    return jsonify({
        "categories": [],
        "count": 0
    }) 
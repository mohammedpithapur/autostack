from flask import Blueprint

bp = Blueprint('cart', __name__)

from app.api.cart import routes 
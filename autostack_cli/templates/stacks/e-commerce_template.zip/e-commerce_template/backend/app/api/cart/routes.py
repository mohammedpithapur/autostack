from flask import jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.api.cart import bp
from app.models import Cart, Product, User
from app import db

@bp.route('/items', methods=['GET'])
@jwt_required()
def get_cart_items():
    """Get all cart items for the current user."""
    user_id = get_jwt_identity()
    
    cart_items = Cart.query.filter_by(user_id=user_id).all()
    return jsonify({
        "cart_items": [item.to_dict() for item in cart_items],
        "count": len(cart_items),
        "total_price": sum(item.quantity * item.product.price for item in cart_items if item.product)
    })

@bp.route('/add', methods=['POST'])
@jwt_required()
def add_to_cart():
    """Add an item to the cart."""
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if not all(k in data for k in ('product_id', 'quantity')):
        return jsonify({"message": "Missing required fields"}), 400
    
    product_id = data['product_id']
    quantity = int(data['quantity'])
    
    if quantity <= 0:
        return jsonify({"message": "Quantity must be greater than zero"}), 400
    
    # Check if product exists
    product = Product.query.get(product_id)
    if not product:
        return jsonify({"message": "Product not found"}), 404
    
    # Check if product is already in cart
    cart_item = Cart.query.filter_by(user_id=user_id, product_id=product_id).first()
    
    if cart_item:
        # Update quantity if already in cart
        cart_item.quantity += quantity
        message = "Cart item quantity updated"
    else:
        # Create new cart item
        cart_item = Cart(user_id=user_id, product_id=product_id, quantity=quantity)
        db.session.add(cart_item)
        message = "Item added to cart"
    
    try:
        db.session.commit()
        return jsonify({
            "message": message,
            "cart_item": cart_item.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error adding to cart: {str(e)}"}), 500

@bp.route('/update/<int:item_id>', methods=['PUT'])
@jwt_required()
def update_cart_item(item_id):
    """Update the quantity of a cart item."""
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if 'quantity' not in data:
        return jsonify({"message": "Missing quantity"}), 400
    
    quantity = int(data['quantity'])
    
    if quantity <= 0:
        return jsonify({"message": "Quantity must be greater than zero"}), 400
    
    # Check if cart item exists and belongs to user
    cart_item = Cart.query.filter_by(id=item_id, user_id=user_id).first()
    
    if not cart_item:
        return jsonify({"message": "Cart item not found"}), 404
    
    # Update quantity
    cart_item.quantity = quantity
    
    try:
        db.session.commit()
        return jsonify({
            "message": "Cart item updated",
            "cart_item": cart_item.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error updating cart: {str(e)}"}), 500

@bp.route('/remove/<int:item_id>', methods=['DELETE'])
@jwt_required()
def remove_from_cart(item_id):
    """Remove an item from the cart."""
    user_id = get_jwt_identity()
    
    # Check if cart item exists and belongs to user
    cart_item = Cart.query.filter_by(id=item_id, user_id=user_id).first()
    
    if not cart_item:
        return jsonify({"message": "Cart item not found"}), 404
    
    try:
        db.session.delete(cart_item)
        db.session.commit()
        return jsonify({
            "message": "Item removed from cart"
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error removing from cart: {str(e)}"}), 500

@bp.route('/clear', methods=['DELETE'])
@jwt_required()
def clear_cart():
    """Clear all items from the cart."""
    user_id = get_jwt_identity()
    
    try:
        Cart.query.filter_by(user_id=user_id).delete()
        db.session.commit()
        return jsonify({
            "message": "Cart cleared"
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error clearing cart: {str(e)}"}), 500 
import React from 'react';

const restaurants = [
  { name: 'Pizza Palace', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&auto=format&fit=crop', cuisine: 'Pizza', rating: 4.7 },
  { name: 'Burger Town', image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop', cuisine: 'Burgers', rating: 4.5 },
  { name: 'Sushi World', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop', cuisine: 'Asian', rating: 4.8 },
  { name: 'Curry House', image: 'https://images.unsplash.com/photo-1505250469679-203ad9ced0cb?w=800&auto=format&fit=crop', cuisine: 'Indian', rating: 4.6 },
  { name: 'Dragon Express', image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800&auto=format&fit=crop', cuisine: 'Chinese', rating: 4.4 },
  { name: 'Sweet Treats', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop', cuisine: 'Desserts', rating: 4.9 },
];

const RestaurantGrid: React.FC = () => (
  <section className="py-16 container mx-auto px-4">
    <h2 className="text-3xl font-bold text-center mb-12">Featured Restaurants</h2>
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
      {restaurants.map((r) => (
        <div key={r.name} className="bg-white rounded-lg shadow-card overflow-hidden">
          <img src={r.image} alt={r.name} className="w-full h-48 object-cover" />
          <div className="p-6">
            <h3 className="text-xl font-bold mb-2">{r.name}</h3>
            <p className="text-gray-600 mb-2">{r.cuisine}</p>
            <span className="text-yellow-500 font-bold">★ {r.rating}</span>
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default RestaurantGrid; 
import React from 'react';

const categories = [
  { name: 'Pizza', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&auto=format&fit=crop' },
  { name: 'Burgers', image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop' },
  { name: 'Asian', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Desserts', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Salads', image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800&auto=format&fit=crop' },
  { name: 'Mexican', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
];

const Hero: React.FC = () => (
  <section className="bg-gradient-hero text-gray-900 py-16 text-center">
    <h1 className="text-5xl font-bold mb-4">Order food from your favorite restaurants</h1>
    <p className="text-xl mb-8">Fast delivery. Great restaurants. All in one place.</p>
    <div className="flex flex-wrap justify-center gap-8 mt-8">
      {categories.map((cat) => (
        <div key={cat.name} className="flex flex-col items-center">
          <img src={cat.image} alt={cat.name} className="w-24 h-24 rounded-full object-cover mb-2 shadow-lg" />
          <span className="font-semibold text-lg">{cat.name}</span>
        </div>
      ))}
    </div>
  </section>
);

export default Hero; 
import React from 'react';

const Footer: React.FC = () => (
  <footer className="bg-gray-900 text-gray-200 py-10 mt-12">
    <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
      <div className="mb-4 md:mb-0">
        <span className="text-orange-500 font-bold text-xl">DashFoods</span>
        <span className="ml-2 text-sm">Your favorite food, delivered fast.</span>
      </div>
      <div className="flex flex-wrap gap-8 text-sm">
        <div>
          <div className="font-semibold mb-2">COMPANY</div>
          <div>About Us</div>
          <div>Careers</div>
          <div>Press</div>
          <div>Blog</div>
        </div>
        <div>
          <div className="font-semibold mb-2">SUPPORT</div>
          <div>Help Center</div>
          <div>Contact Us</div>
          <div>FAQs</div>
        </div>
        <div>
          <div className="font-semibold mb-2">LEGAL</div>
          <div>Terms of Service</div>
          <div>Privacy Policy</div>
          <div>Cookie Policy</div>
        </div>
      </div>
    </div>
    <div className="text-center text-xs text-gray-500 mt-8">&copy; {new Date().getFullYear()} DashFoods. All rights reserved.</div>
  </footer>
);

export default Footer; 
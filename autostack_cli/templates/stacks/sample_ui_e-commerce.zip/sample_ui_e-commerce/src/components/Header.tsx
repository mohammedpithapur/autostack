import React from 'react';

const Header: React.FC = () => (
  <header className="bg-white shadow py-4 px-8 flex items-center justify-between">
    <div className="text-2xl font-bold text-orange-500">DashFoods</div>
    <nav className="space-x-6">
      <a href="#" className="text-gray-700 hover:text-orange-500 font-medium">Home</a>
      <a href="#" className="text-gray-700 hover:text-orange-500 font-medium">Categories</a>
      <a href="#" className="text-gray-700 hover:text-orange-500 font-medium">Restaurants</a>
      <a href="#" className="text-gray-700 hover:text-orange-500 font-medium">Sign In</a>
      <a href="#" className="ml-2 px-4 py-2 bg-orange-500 text-white rounded hover:bg-orange-600 font-semibold">Sign Up</a>
    </nav>
  </header>
);

export default Header; 
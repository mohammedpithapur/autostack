import React from 'react';

const categories = [
  { name: 'Pizza', image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&auto=format&fit=crop' },
  { name: 'Burgers', image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?w=800&auto=format&fit=crop' },
  { name: 'Asian', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Desserts', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Salads', image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=800&auto=format&fit=crop' },
  { name: 'Mexican', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Indian', image: 'https://images.unsplash.com/photo-1505250469679-203ad9ced0cb?w=800&auto=format&fit=crop' },
  { name: 'Thai', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Mediterranean', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Breakfast', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Seafood', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
  { name: 'Vegetarian', image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&auto=format&fit=crop' },
];

const CategoryList: React.FC = () => (
  <section className="py-10 container mx-auto px-4">
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-2xl font-bold">Top Categories</h2>
      <button className="flex items-center gap-1 text-orange-500 hover:underline font-semibold text-sm">
        View All <span className="text-lg">&rarr;</span>
      </button>
    </div>
    <div className="flex gap-6 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-orange-200">
      {categories.map((cat) => (
        <div key={cat.name} className="flex-shrink-0 w-32 cursor-pointer group">
          <div className="rounded-xl overflow-hidden shadow-card group-hover:shadow-lg transition-shadow duration-200">
            <img src={cat.image} alt={cat.name} className="w-full h-24 object-cover group-hover:scale-105 transition-transform duration-200" />
          </div>
          <div className="mt-2 text-center font-medium text-gray-800 group-hover:text-orange-500">
            {cat.name}
          </div>
        </div>
      ))}
    </div>
  </section>
);

export default CategoryList; 
import React from 'react';
import Header from './components/Header';
import CategoryList from './components/CategoryList';
import Hero from './components/Hero';
import RestaurantGrid from './components/RestaurantGrid';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <CategoryList />
      <main className="flex-grow">
        <Hero />
        <RestaurantGrid />
      </main>
      <Footer />
    </div>
  );
};

export default App; 
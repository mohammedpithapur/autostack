# DashFoods Clone

A DoorDash-like food delivery app built with React + Vite + Tailwind CSS.

## Project Structure
- Config files adapted from react-flask-saas-marketing
- src/components: Header, Footer, Hero, RestaurantGrid, CategoryList, etc.
- src/layout: Main layout

## Getting Started
1. Install dependencies
2. Run the dev server

---

This project is a static UI clone for demonstration purposes. 
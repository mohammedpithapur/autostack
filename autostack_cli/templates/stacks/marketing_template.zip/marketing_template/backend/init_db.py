import os
from app import create_app, db
from app.models import User, Service

# Initialize app and context
app = create_app()
app.app_context().push()

def init_db():
    """Initialize the database with tables and sample data."""
    # Create tables
    db.create_all()
    print("Tables created.")
    
    # Create admin user if not exists
    if not User.query.filter_by(email='admin@example.com').first():
        admin = User(
            email='admin@example.com',
            name='Admin User',
            role='admin'
        )
        admin.set_password('adminpassword')
        db.session.add(admin)
        
        # Create regular user if not exists
        user = User(
            email='user@example.com',
            name='Regular User',
            role='customer'
        )
        user.set_password('userpassword')
        db.session.add(user)
        
        db.session.commit()
        print("Users created.")
        
    # Create sample services if not exists
    if Service.query.count() == 0:
        services = [
            {
                'id': 1,
                'name': 'Effortless Team Collaboration',
                'description': 'Collaborate with your team in real-time and manage tasks efficiently.',
                'image_url': 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop',
                'category': 'Collaboration',
            },
            {
                'id': 2,
                'name': 'Analytics Dashboard',
                'description': 'Gain insights with customizable, real-time analytics dashboards.',
                'image_url': 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop',
                'category': 'Analytics',
            },
            {
                'id': 3,
                'name': 'Secure Cloud Storage',
                'description': 'Your data is safe and accessible with our top-tier cloud storage.',
                'image_url': 'https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&auto=format&fit=crop',
                'category': 'Storage',
            },
            {
                'id': 4,
                'name': 'Customer Relationship Management',
                'description': 'Build and maintain strong customer relationships with our intuitive CRM.',
                'image_url': 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&auto=format&fit=crop',
                'category': 'CRM',
            },
            {
                'id': 5,
                'name': 'Email Marketing Platform',
                'description': 'Engage your audience with powerful email marketing campaigns.',
                'image_url': 'https://images.unsplash.com/photo-1586953208448-315b2c39d053?w=800&auto=format&fit=crop',
                'category': 'Marketing',
            },
            {
                'id': 6,
                'name': 'Project Management Suite',
                'description': 'Plan, execute, and track your projects with our comprehensive suite of tools.',
                'image_url': 'https://images.unsplash.com/photo-1529228302246-999c3e3b0125?w=800&auto=format&fit=crop',
                'category': 'Productivity',
            },
        ]
        
        for service_data in services:
            service = Service(**service_data)
            db.session.add(service)
            
        db.session.commit()
        print("Sample services created.")
    
    print("Database initialized successfully!")

if __name__ == '__main__':
    # Check if DB file exists
    db_path = os.path.join(app.instance_path, 'saas_marketing.db')
    db_exists = os.path.exists(db_path)
    
    # Ensure instance path exists
    os.makedirs(app.instance_path, exist_ok=True)
    
    # Initialize the database
    init_db()
    
    print(f"Database location: {db_path}")
    if not db_exists:
        print("New database was created.")
    else:
        print("Existing database was updated.")

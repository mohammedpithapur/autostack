from flask import request, jsonify, current_app
from werkzeug.security import check_password_hash
from flask_jwt_extended import (
    create_access_token, create_refresh_token, 
    jwt_required, get_jwt_identity, 
    set_access_cookies, set_refresh_cookies,
    unset_jwt_cookies
)
from app.api.auth import bp
from app import db
from app.models import User

@bp.route('/register', methods=['POST'])
def register():
    """Register a new user."""
    data = request.get_json()
    
    # Validate required fields
    if not all(k in data for k in ('email', 'name', 'password')):
        return jsonify({"message": "Missing required fields"}), 400
    
    # Check if user already exists
    if User.query.filter_by(email=data['email']).first():
        return jsonify({"message": "Email already registered"}), 400
    
    # Create new user
    user = User(email=data['email'], name=data['name'])
    user.set_password(data['password'])
    
    try:
        db.session.add(user)
        db.session.commit()
        
        # Create tokens
        access_token = create_access_token(identity=user.id)
        refresh_token = create_refresh_token(identity=user.id)
        
        response = jsonify({
            "message": "User registered successfully",
            "user": user.to_dict()
        })
        
        # Set cookies
        set_access_cookies(response, access_token)
        set_refresh_cookies(response, refresh_token)
        
        return response, 201
    
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Error registering user: {str(e)}")
        return jsonify({"message": "An error occurred during registration"}), 500

@bp.route('/login', methods=['POST'])
def login():
    """Login a user."""
    data = request.get_json()
    
    # Validate required fields
    if not all(k in data for k in ('email', 'password')):
        return jsonify({"message": "Missing email or password"}), 400
    
    # Check if user exists
    user = User.query.filter_by(email=data['email']).first()
    if not user or not user.check_password(data['password']):
        return jsonify({"message": "Invalid email or password"}), 401
    
    # Create tokens
    access_token = create_access_token(identity=user.id)
    refresh_token = create_refresh_token(identity=user.id)
    
    response = jsonify({
        "message": "Login successful",
        "user": user.to_dict()
    })
    
    # Set cookies
    set_access_cookies(response, access_token)
    set_refresh_cookies(response, refresh_token)
    
    return response

@bp.route('/logout', methods=['POST'])
def logout():
    """Logout a user by clearing cookies."""
    response = jsonify({"message": "Logout successful"})
    unset_jwt_cookies(response)
    return response

@bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get the current authenticated user."""
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    
    if not user:
        return jsonify({"message": "User not found"}), 404
    
    return jsonify({"user": user.to_dict()})

@bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh_token():
    """Refresh the access token."""
    user_id = get_jwt_identity()
    access_token = create_access_token(identity=user_id)
    
    response = jsonify({
        "message": "Token refreshed"
    })
    set_access_cookies(response, access_token)
    
    return response 
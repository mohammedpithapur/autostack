from flask import jsonify, request
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.api.lists import bp
from app.models import List, Service, User
from app import db

@bp.route('/items', methods=['GET'])
@jwt_required()
def get_list_items():
    """Get all list items for the current user."""
    user_id = get_jwt_identity()
    
    list_items = List.query.filter_by(user_id=user_id).all()
    return jsonify({
        "list_items": [item.to_dict() for item in list_items],
        "count": len(list_items)
    })

@bp.route('/add', methods=['POST'])
@jwt_required()
def add_to_list():
    """Add an item to the list."""
    user_id = get_jwt_identity()
    data = request.get_json()
    
    if 'service_id' not in data:
        return jsonify({"message": "Missing required fields"}), 400
    
    service_id = data['service_id']
    
    # Check if service exists
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"message": "Service not found"}), 404
    
    # Check if service is already in list
    list_item = List.query.filter_by(user_id=user_id, service_id=service_id).first()
    
    if list_item:
        return jsonify({"message": "Service already in list"}), 400
    
    # Create new list item
    list_item = List(user_id=user_id, service_id=service_id)
    db.session.add(list_item)
    
    try:
        db.session.commit()
        return jsonify({
            "message": "Item added to list",
            "list_item": list_item.to_dict()
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error adding to list: {str(e)}"}), 500

@bp.route('/remove/<int:item_id>', methods=['DELETE'])
@jwt_required()
def remove_from_list(item_id):
    """Remove an item from the list."""
    user_id = get_jwt_identity()
    
    # Check if list item exists and belongs to user
    list_item = List.query.filter_by(id=item_id, user_id=user_id).first()
    
    if not list_item:
        return jsonify({"message": "List item not found"}), 404
    
    try:
        db.session.delete(list_item)
        db.session.commit()
        return jsonify({
            "message": "Item removed from list"
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({"message": f"Error removing from list: {str(e)}"}), 500

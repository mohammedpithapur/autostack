from flask import jsonify
from app.api.services import bp
from app.models import Service

@bp.route('/', methods=['GET'])
def get_services():
    """Get all services."""
    services = Service.query.all()
    return jsonify({
        "services": [service.to_dict() for service in services]
    })

@bp.route('/<int:service_id>', methods=['GET'])
def get_service(service_id):
    """Get a specific service by ID."""
    service = Service.query.get(service_id)
    if not service:
        return jsonify({"message": "Service not found"}), 404
    return jsonify(service.to_dict())

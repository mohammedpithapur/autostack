import os
from flask import Flask, jsonify
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_jwt_extended import JWTManager
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize SQLAlchemy with no specific settings yet
db = SQLAlchemy()
migrate = Migrate()
jwt = JWTManager()

def create_app():
    """Application factory pattern."""
    app = Flask(__name__, static_folder=None)
    
    # Configure the Flask app
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev'),
        SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL', 'sqlite:///saas_marketing.db'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        JWT_SECRET_KEY=os.environ.get('JWT_SECRET_KEY', 'dev-jwt-key'),
        JWT_ACCESS_TOKEN_EXPIRES=int(os.environ.get('JWT_ACCESS_TOKEN_EXPIRES', 3600)),  # 1 hour
        JWT_REFRESH_TOKEN_EXPIRES=int(os.environ.get('JWT_REFRESH_TOKEN_EXPIRES', 2592000)),  # 30 days
        JWT_TOKEN_LOCATION=['cookies'],
        JWT_COOKIE_SECURE=False,  # Set to True in production with HTTPS
        JWT_COOKIE_CSRF_PROTECT=False,  # Disabled for now for easier development
        JWT_CSRF_IN_COOKIES=True,
    )
    
    # Enable CORS
    CORS(app, supports_credentials=True)
    
    # Initialize extensions with app
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)
    
    # Import models
    from app.models import User
    
    # Register blueprints
    from app.api.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/api/auth')

    from app.api.services import bp as services_bp
    app.register_blueprint(services_bp, url_prefix='/api/services')

    from app.api.lists import bp as lists_bp
    app.register_blueprint(lists_bp, url_prefix='/api/lists')
    
    # Health check endpoint
    @app.route('/api/health')
    def health_check():
        return {"status": "ok"}, 200
    
    return app

from app import create_app, db
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()


app = create_app()

with app.app_context():
    # Create database tables and seed initial data
    from app.models import User, Service
    db.create_all()
    print("Database tables created")
    # Seed admin user
    if not User.query.filter_by(email='admin@example.com').first():
        admin = User(
            email='admin@example.com',
            name='Admin User',
            role='admin'
        )
        admin.set_password('adminpassword')
        db.session.add(admin)
        user = User(
            email='user@example.com',
            name='Regular User',
            role='customer'
        )
        user.set_password('userpassword')
        db.session.add(user)
        db.session.commit()
        print("Users created.")
    # Seed sample services
    if Service.query.count() == 0:
        services = [
            {
                'id': 1,
                'name': 'Effortless Team Collaboration',
                'description': 'Collaborate with your team in real-time and manage tasks efficiently.',
                'image_url': 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop',
                'category': 'Collaboration',
            },
            {
                'id': 2,
                'name': 'Analytics Dashboard',
                'description': 'Gain insights with customizable, real-time analytics dashboards.',
                'image_url': 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop',
                'category': 'Analytics',
            },
            {
                'id': 3,
                'name': 'Secure Cloud Storage',
                'description': 'Your data is safe and accessible with our top-tier cloud storage.',
                'image_url': 'https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&auto=format&fit=crop',
                'category': 'Storage',
            },
            {
                'id': 4,
                'name': 'Customer Relationship Management',
                'description': 'Build and maintain strong customer relationships with our intuitive CRM.',
                'image_url': 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&auto=format&fit=crop',
                'category': 'CRM',
            },
            {
                'id': 5,
                'name': 'Email Marketing Platform',
                'description': 'Engage your audience with powerful email marketing campaigns.',
                'image_url': 'https://images.unsplash.com/photo-1586953208448-315b2c39d053?w=800&auto=format&fit=crop',
                'category': 'Marketing',
            },
            {
                'id': 6,
                'name': 'Project Management Suite',
                'description': 'Plan, execute, and track your projects with our comprehensive suite of tools.',
                'image_url': 'https://images.unsplash.com/photo-1529228302246-999c3e3b0125?w=800&auto=format&fit=crop',
                'category': 'Productivity',
            },
        ]
        for service_data in services:
            service = Service(**service_data)
            db.session.add(service)
        db.session.commit()
        print("Sample services created.")
    print("Database initialized successfully!")

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000))) 
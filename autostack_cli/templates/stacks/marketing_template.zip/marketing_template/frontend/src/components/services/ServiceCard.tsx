import React from 'react';
import { Link } from 'react-router-dom';
import { useList } from '../../contexts/ListContext';

type Service = {
  id: number;
  title: string;
  description: string;
  image_url: string;
  category: string;
};

interface ServiceCardProps {
  service: Service;
}

export default function ServiceCard({ service }: ServiceCardProps) {
  const { addToList } = useList();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <Link to={`/services/${service.id}`}>
        <div className="aspect-video relative overflow-hidden">
          <img
            src={service.image_url}
            alt={service.title}
            className="object-cover w-full h-full hover:scale-105 transition-transform"
          />
        </div>
        
        <div className="p-4">
          <h3 className="text-lg font-semibold text-gray-800 mb-1 truncate">{service.title}</h3>
          <p className="text-sm text-gray-600 mb-2 line-clamp-2 h-10">{service.description}</p>
          
          <div className="flex items-center justify-between mt-4">
            <span className="text-primary font-bold text-lg">{service.category}</span>
            <button
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                addToList(service.id);
              }}
              className="bg-primary text-white px-6 py-2 rounded-md hover:bg-primary-dark flex items-center justify-center gap-2"
              aria-label="Add to List"
            >
              <span>Add to List</span>
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
}

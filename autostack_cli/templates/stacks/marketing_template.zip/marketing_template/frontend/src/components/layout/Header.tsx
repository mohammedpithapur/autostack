import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { useList } from '../../contexts/ListContext';

export default function Header() {
  const { isAuthenticated, user, logout } = useAuth();
  const { itemCount } = useList();

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-gray-800">
          SaaSify
        </Link>
        <nav className="hidden md:flex space-x-6">
          <a href="/#features" className="text-gray-600 hover:text-gray-800">
            Features
          </a>
          <a href="/#pricing" className="text-gray-600 hover:text-gray-800">
            Pricing
          </a>
          <a href="/#testimonials" className="text-gray-600 hover:text-gray-800">
            Testimonials
          </a>
          <a href="/#faq" className="text-gray-600 hover:text-gray-800">
            FAQ
          </a>
        </nav>
        <div className="hidden md:flex items-center space-x-4">
          {isAuthenticated ? (
            <>
              <Link
                to="/my-list"
                className="text-gray-600 hover:text-gray-800 flex items-center"
              >
                My List
                {itemCount > 0 && (
                  <span className="ml-2 bg-primary text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Link>
              <Link
                to="/my-profile"
                className="text-gray-600 hover:text-gray-800"
              >
                My Profile
              </Link>
              <button
                onClick={logout}
                className="text-gray-600 hover:text-gray-800"
              >
                Logout
              </button>
            </>
          ) : (
            <>
              <Link
                to="/auth/login"
                className="text-gray-600 hover:text-gray-800"
              >
                Sign In
              </Link>
              <Link
                to="/auth/register"
                className="bg-primary text-white px-4 py-2 rounded-md hover:bg-primary-dark"
              >
                Get Started
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

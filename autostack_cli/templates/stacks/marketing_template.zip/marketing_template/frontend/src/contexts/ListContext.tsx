import React, { createContext, useCallback, useEffect, useState, ReactNode, useContext } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import { useAuth } from '../hooks/useAuth';

const API_URL = 'http://localhost:5000/api';

type Service = {
  id: number;
  name: string;
  description: string;
  image_url: string;
  category: string;
};

type ListItem = {
  id: number;
  service_id: number;
  service: Service;
};

type ListContextType = {
  listItems: ListItem[];
  itemCount: number;
  isLoading: boolean;
  addToList: (serviceId: number) => Promise<void>;
  removeFromList: (itemId: number) => Promise<void>;
  refreshList: () => Promise<void>;
};

export const ListContext = createContext<ListContextType | undefined>(undefined);

export const useList = () => {
  const context = useContext(ListContext);
  if (!context) {
    throw new Error('useList must be used within a ListProvider');
  }
  return context;
};

export const ListProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [listItems, setListItems] = useState<ListItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { isAuthenticated } = useAuth();

  const itemCount = listItems.length;

  const refreshList = useCallback(async () => {
    if (!isAuthenticated) {
      setListItems([]);
      return;
    }
    setIsLoading(true);
    try {
      const response = await axios.get(`${API_URL}/lists/items`);
      setListItems(response.data.list_items || []);
    } catch (error) {
      console.error('Failed to fetch list:', error);
      setListItems([]);
    } finally {
      setIsLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    refreshList();
  }, [refreshList]);

  const addToList = async (serviceId: number) => {
    if (!isAuthenticated) {
      toast.error("Please log in to add items to your list.");
      return;
    }
    setIsLoading(true);
    try {
      await axios.post(`${API_URL}/lists/add`, { service_id: serviceId });
      await refreshList();
      toast.success("Service added to your list");
    } catch (error: any) {
      console.error('Failed to add item to list:', error);
      const errorMessage = error.response?.data?.message || "Failed to add item to list.";
      toast.error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const removeFromList = async (itemId: number) => {
    setIsLoading(true);
    try {
      await axios.delete(`${API_URL}/lists/remove/${itemId}`);
      await refreshList();
      toast.success("Service removed from your list");
    } catch (error) {
      console.error('Failed to remove item from list:', error);
      toast.error("Failed to remove item from list.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ListContext.Provider
      value={{
        listItems,
        itemCount,
        isLoading,
        addToList,
        removeFromList,
        refreshList,
      }}
    >
      {children}
    </ListContext.Provider>
  );
};

import React from 'react';
import { createContext, useCallback, useEffect, useState, ReactNode } from 'react';
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

type User = {
  id: number;
  name: string;
  email: string;
  role: string;
};

type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

export const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  register: async () => {},
  logout: async () => {},
});

export const AuthProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Set up axios defaults
  axios.defaults.withCredentials = true;

  const checkAuth = useCallback(async () => {
    try {
      const response = await axios.get(`${API_URL}/auth/me`);
      if (response.data && response.data.user) {
        setUser(response.data.user);
      }
    } catch (error) {
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    checkAuth();
  }, [checkAuth]);

  const login = async (email: string, password: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/login`, { email, password });
      if (response.data && response.data.user) {
        setUser(response.data.user);
        return Promise.resolve();
      }
      return Promise.reject(new Error('Invalid response from server'));
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        return Promise.reject(new Error(error.response.data.message || 'Login failed'));
      }
      return Promise.reject(new Error('Login failed'));
    }
  };

  const register = async (name: string, email: string, password: string) => {
    try {
      const response = await axios.post(`${API_URL}/auth/register`, { name, email, password });
      if (response.data && response.data.user) {
        setUser(response.data.user);
        return Promise.resolve();
      }
      return Promise.reject(new Error('Invalid response from server'));
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        return Promise.reject(new Error(error.response.data.message || 'Registration failed'));
      }
      return Promise.reject(new Error('Registration failed'));
    }
  };

  const logout = async () => {
    try {
      await axios.post(`${API_URL}/auth/logout`);
      setUser(null);
      return Promise.resolve();
    } catch (error) {
      return Promise.reject(new Error('Logout failed'));
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}; 
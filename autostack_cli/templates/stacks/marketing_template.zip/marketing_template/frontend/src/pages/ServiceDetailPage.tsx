import React from 'react';
import { useParams, Link } from 'react-router-dom';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { useList } from '../contexts/ListContext';

const services = [
  {
    id: 1,
    title: 'Effortless Team Collaboration',
    description: 'Collaborate with your team in real-time and manage tasks efficiently. Our platform provides a centralized hub for communication, file sharing, and project management, ensuring your team stays aligned and productive.',
    image_url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop',
    category: 'Collaboration',
  },
  {
    id: 2,
    title: 'Analytics Dashboard',
    description: 'Gain insights with customizable, real-time analytics dashboards. Track key metrics, visualize data, and make informed decisions to drive your business forward.',
    image_url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop',
    category: 'Analytics',
  },
  {
    id: 3,
    title: 'Secure Cloud Storage',
    description: 'Your data is safe and accessible with our top-tier cloud storage. We offer robust security features, automatic backups, and seamless integration with your existing workflow.',
    image_url: 'https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&auto=format&fit=crop',
    category: 'Storage',
  },
    {
    id: 4,
    title: 'Customer Relationship Management',
    description: 'Build and maintain strong customer relationships with our intuitive CRM.',
    image_url: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&auto=format&fit=crop',
    category: 'CRM',
  },
  {
    id: 5,
    title: 'Email Marketing Platform',
    description: 'Engage your audience with powerful email marketing campaigns.',
    image_url: 'https://images.unsplash.com/photo-1557200134-90327ee9f6d5?w=800&auto=format&fit=crop',
    category: 'Marketing',
  },
  {
    id: 6,
    title: 'Project Management Suite',
    description: 'Plan, execute, and track your projects with our comprehensive suite of tools.',
    image_url: 'https://images.unsplash.com/photo-1529228302246-999c3e3b0125?w=800&auto=format&fit=crop',
    category: 'Productivity',
  },
];

export default function ServiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { addToList } = useList();
  const service = services.find((s) => s.id === parseInt(id || ''));

  if (!service) {
    return <div>Service not found</div>;
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <div className="bg-white p-8 rounded-lg shadow-lg max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <img
                src={service.image_url}
                alt={service.title}
                className="w-full h-auto object-cover rounded-lg shadow-md"
              />
            </div>
            <div className="flex flex-col justify-center">
              <span className="text-primary font-semibold mb-2">{service.category}</span>
              <h1 className="text-4xl font-bold mb-4">{service.title}</h1>
              <p className="text-gray-600 mb-6">{service.description}</p>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => addToList(service.id)}
                  className="bg-primary text-white px-6 py-3 rounded-md hover:bg-primary-dark transition"
                >
                  Add to List
                </button>
                <Link to="/" className="text-gray-600 hover:text-gray-800">
                  Back to List
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}

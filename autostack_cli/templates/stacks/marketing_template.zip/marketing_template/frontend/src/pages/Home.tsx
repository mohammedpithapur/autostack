import React, { useState } from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import { Link } from 'react-router-dom';
import ServiceCard from '../components/services/ServiceCard';

const services = [
  {
    id: 1,
    title: 'Effortless Team Collaboration',
    description: 'Collaborate with your team in real-time and manage tasks efficiently.',
    image_url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&auto=format&fit=crop',
    category: 'Collaboration',
  },
  {
    id: 2,
    title: 'Analytics Dashboard',
    description: 'Gain insights with customizable, real-time analytics dashboards.',
    image_url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop',
    category: 'Analytics',
  },
  {
    id: 3,
    title: 'Secure Cloud Storage',
    description: 'Your data is safe and accessible with our top-tier cloud storage.',
    image_url: 'https://images.unsplash.com/photo-1543286386-713bdd548da4?w=800&auto=format&fit=crop',
    category: 'Storage',
  },
  {
    id: 4,
    title: 'Customer Relationship Management',
    description: 'Build and maintain strong customer relationships with our intuitive CRM.',
    image_url: 'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?w=800&auto=format&fit=crop',
    category: 'CRM',
  },
  {
    id: 5,
    title: 'Email Marketing Platform',
    description: 'Engage your audience with powerful email marketing campaigns.',
    image_url: 'https://images.unsplash.com/photo-1586281380117-5a60ae2050cc?w=800&auto=format&fit=crop',
    category: 'Marketing',
  },
  {
    id: 6,
    title: 'Project Management Suite',
    description: 'Plan, execute, and track your projects with our comprehensive suite of tools.',
    image_url: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?w=800&auto=format&fit=crop',
    category: 'Productivity',
  },
];

export default function Home() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary text-white text-center py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-4">
              Build Your SaaS Faster Than Ever
            </h1>
            <p className="text-xl mb-8">
              A boilerplate with all you need to build your SaaS product.
            </p>
            <Link
              to="/auth/register"
              className="bg-white text-primary font-bold py-3 px-8 rounded-md hover:bg-gray-200"
            >
              Get Started for Free
            </Link>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              Latest Content
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {services.map((service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section id="pricing" className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              Pricing Plans
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Plan 1 */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold mb-4">Starter</h3>
                <p className="text-4xl font-bold mb-4">Free</p>
                <ul className="space-y-2 text-gray-600">
                  <li>1 Project</li>
                  <li>Up to 500 users</li>
                  <li>Basic Analytics</li>
                  <li>Community Support</li>
                </ul>
                <button className="mt-8 w-full bg-primary text-white py-3 rounded-md">
                  Start Now
                </button>
              </div>
              {/* Plan 2 */}
              <div className="bg-white p-8 rounded-lg shadow-md border-2 border-primary">
                <h3 className="text-2xl font-bold mb-4">Pro</h3>
                <p className="text-4xl font-bold mb-4">$29/mo</p>
                <ul className="space-y-2 text-gray-600">
                  <li>Unlimited Projects</li>
                  <li>Up to 10,000 users</li>
                  <li>Advanced Analytics</li>
                  <li>Priority Support</li>
                  <li>3 Integrations</li>
                </ul>
                <button className="mt-8 w-full bg-primary text-white py-3 rounded-md">
                  Start Now
                </button>
              </div>
              {/* Plan 3 */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <h3 className="text-2xl font-bold mb-4">Enterprise</h3>
                <p className="text-4xl font-bold mb-4">Contact Us</p>
                <ul className="space-y-2 text-gray-600">
                  <li>Custom Projects</li>
                  <li>Unlimited Users</li>
                  <li>Dedicated Success Manager</li>
                  <li>SLA & Compliance</li>
                  <li>All Integrations</li>
                </ul>
                <button className="mt-8 w-full bg-primary text-white py-3 rounded-md">
                  Contact Sales
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              What Our Customers Say
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Testimonial 1 */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Alice W." className="w-16 h-16 rounded-full mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  "SaaSify made launching our MVP a breeze. The UI is
                  gorgeous and the analytics are a game changer!"
                </p>
                <p className="font-bold">Alice W.</p>
                <p className="text-sm text-gray-500">@Acme Inc.</p>
              </div>
              {/* Testimonial 2 */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="Jake R." className="w-16 h-16 rounded-full mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  "We scaled from 100 to 10,000 users in months. Their
                  support is top notch and integrations just work."
                </p>
                <p className="font-bold">Jake R.</p>
                <p className="text-sm text-gray-500">@CloudNova</p>
              </div>
              {/* Testimonial 3 */}
              <div className="bg-white p-8 rounded-lg shadow-md">
                <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="Priya D." className="w-16 h-16 rounded-full mx-auto mb-4" />
                <p className="text-gray-600 mb-4">
                  "The best SaaS platform for startups. Customizable, secure,
                  and beautiful out of the box."
                </p>
                <p className="font-bold">Priya D.</p>
                <p className="text-sm text-gray-500">@SaaSBoost</p>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section id="faq" className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              Frequently Asked Questions
            </h2>
            <div className="max-w-3xl mx-auto">
              {/* FAQ 1 */}
              <div className="mb-4 border-b">
                <button
                  className="w-full text-left py-4 focus:outline-none flex justify-between items-center"
                  onClick={() => setOpenFaq(openFaq === 1 ? null : 1)}
                >
                  <h3 className="text-xl font-bold">
                    Can I use SaaSify for free?
                  </h3>
                  <svg
                    className={`w-6 h-6 transition-transform ${openFaq === 1 ? 'transform rotate-180' : ''
                      }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {openFaq === 1 && (
                  <p className="text-gray-600 pb-4">
                    Yes, our Starter plan is free and includes all the basic
                    features to get you started.
                  </p>
                )}
              </div>
              {/* FAQ 2 */}
              <div className="mb-4 border-b">
                <button
                  className="w-full text-left py-4 focus:outline-none flex justify-between items-center"
                  onClick={() => setOpenFaq(openFaq === 2 ? null : 2)}
                >
                  <h3 className="text-xl font-bold">
                    Is my data secure?
                  </h3>
                  <svg
                    className={`w-6 h-6 transition-transform ${openFaq === 2 ? 'transform rotate-180' : ''
                      }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {openFaq === 2 && (
                  <p className="text-gray-600 pb-4">
                    Yes, we use top-tier cloud providers and industry best
                    practices to ensure your data is safe and secure.
                  </p>
                )}
              </div>
              {/* FAQ 3 */}
              <div className="mb-4 border-b">
                <button
                  className="w-full text-left py-4 focus:outline-none flex justify-between items-center"
                  onClick={() => setOpenFaq(openFaq === 3 ? null : 3)}
                >
                  <h3 className="text-xl font-bold">
                    Can I cancel my subscription anytime?
                  </h3>
                  <svg
                    className={`w-6 h-6 transition-transform ${openFaq === 3 ? 'transform rotate-180' : ''
                      }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {openFaq === 3 && (
                  <p className="text-gray-600 pb-4">
                    Absolutely. You can cancel or downgrade your subscription anytime from your account settings.
                  </p>
                )}
              </div>

              {/* FAQ 4 */}
              <div className="mb-4 border-b">
                <button
                  className="w-full text-left py-4 focus:outline-none flex justify-between items-center"
                  onClick={() => setOpenFaq(openFaq === 4 ? null : 4)}
                >
                  <h3 className="text-xl font-bold">
                    Do you offer customer support?
                  </h3>
                  <svg
                    className={`w-6 h-6 transition-transform ${openFaq === 4 ? 'transform rotate-180' : ''
                      }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {openFaq === 4 && (
                  <p className="text-gray-600 pb-4">
                    Yes, our support team is available 24/7 to assist you via chat or email.
                  </p>
                )}
              </div>

              {/* FAQ 5 */}
              <div className="mb-4 border-b">
                <button
                  className="w-full text-left py-4 focus:outline-none flex justify-between items-center"
                  onClick={() => setOpenFaq(openFaq === 5 ? null : 5)}
                >
                  <h3 className="text-xl font-bold">
                    Can I upgrade my plan later?
                  </h3>
                  <svg
                    className={`w-6 h-6 transition-transform ${openFaq === 5 ? 'transform rotate-180' : ''
                      }`}
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M19 9l-7 7-7-7"
                    />
                  </svg>
                </button>
                {openFaq === 5 && (
                  <p className="text-gray-600 pb-4">
                    Yes, you can upgrade or change your plan at any time without losing your data.
                  </p>
                )}
              </div>

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
